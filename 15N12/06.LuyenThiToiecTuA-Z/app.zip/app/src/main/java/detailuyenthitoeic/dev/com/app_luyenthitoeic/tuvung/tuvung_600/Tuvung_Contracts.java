package detailuyenthitoeic.dev.com.app_luyenthitoeic.tuvung.tuvung_600;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import detailuyenthitoeic.dev.com.app_luyenthitoeic.R;

/**
 * Created by User on 09/09/17.
 */

public class Tuvung_Contracts extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contracts);
    }
}
