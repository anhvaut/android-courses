package detailuyenthitoeic.dev.com.app_luyenthitoeic.tuvung;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import detailuyenthitoeic.dev.com.app_luyenthitoeic.R;
import detailuyenthitoeic.dev.com.app_luyenthitoeic.tuvung.tuvung_600.Contracts;

/**
 * Created by User on 09/08/17.
 */

public class Home_TuVung extends AppCompatActivity{
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_tuvung);
        Button btn_600_Tuvung= (Button) findViewById(R.id.btn_tuvung_theochude);
        btn_600_Tuvung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home_TuVung.this, Contracts.class);
                startActivity(intent);
            }
        });
    }
}
