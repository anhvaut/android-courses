package detailuyenthitoeic.dev.com.app_luyenthitoeic;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import detailuyenthitoeic.dev.com.app_luyenthitoeic.batdau.Btn_Batdau;
import detailuyenthitoeic.dev.com.app_luyenthitoeic.luyenthi.Btn_Luyenthi;
import detailuyenthitoeic.dev.com.app_luyenthitoeic.tuvung.Home_TuVung;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        Button btn_tuvung=(Button) findViewById(R.id.btn_tuvung);
        btn_tuvung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Home_TuVung.class);
                startActivity(intent);
            }
        });
        Button btn_batdau=(Button) findViewById(R.id.btn_batdau);
        btn_batdau.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Btn_Batdau.class);
                startActivity(intent);
            }
        });
        Button btn_luyenthi=(Button) findViewById(R.id.btn_luyenthi);
        btn_luyenthi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Btn_Luyenthi.class);
                startActivity(intent);
            }
        });
    }
}
