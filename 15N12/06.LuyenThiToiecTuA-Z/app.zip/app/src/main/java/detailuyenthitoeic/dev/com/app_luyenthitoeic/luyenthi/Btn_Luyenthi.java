package detailuyenthitoeic.dev.com.app_luyenthitoeic.luyenthi;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import detailuyenthitoeic.dev.com.app_luyenthitoeic.R;

/**
 * Created by User on 09/09/17.
 */

public class Btn_Luyenthi extends AppCompatActivity {
    @Override
    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_luyenthi);
    }
}
