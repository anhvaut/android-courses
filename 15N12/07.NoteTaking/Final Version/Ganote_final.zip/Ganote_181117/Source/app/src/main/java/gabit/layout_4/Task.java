package gabit.layout_4;

import android.icu.util.Calendar;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by Marco on 9/9/2017.
 */

public class Task implements Serializable {
    private String title;
    private String content;
    private Date time;
    private boolean isFinished;
    private boolean alarm;

    public Task(){
        this.title = "No title";
        this.content = "No contents";
        this.isFinished = false;
        Calendar calendar;
        calendar = Calendar.getInstance();
        time = calendar.getTime();
    }
    public Task(String title, String content){
        this.title = title;
        this.content = content;
    }

    public Task(String title, String content, Date time, boolean isFinished, boolean alarm) {
        this.title = title;
        this.content = content;
        this.time = time;
        this.isFinished = isFinished;
        this.alarm = alarm;
    }

    public Task(String title, String content, Date time, boolean isFinished) {
        this.title = title;
        this.content = content;
        this.time = time;
        this.isFinished = isFinished;
        this.alarm = false;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public void setDatetime(String source) throws  ParseException {
        time = new SimpleDateFormat("dd/MM/yyyy hh:mm a").parse(source);
    }

    public boolean isFinished() {
        return isFinished;
    }

    public void setIsFinished(boolean hasAlarm) {
        this.isFinished = hasAlarm;
    }

    public String getDateTimeString(){
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault());
        return sdf.format(time);
    }

    public SimpleDateFormat getDatetimeFormat() {
        return new SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault());
    }

    public boolean isAlarm() {
        return alarm;
    }

    public void setAlarm(boolean alarm) {
        this.alarm = alarm;
    }

    @Override
    public String toString() {
        return "Task{" +
                "title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", time=" + time +
                ", hasAlarm=" + isFinished +
                '}';
    }
}
