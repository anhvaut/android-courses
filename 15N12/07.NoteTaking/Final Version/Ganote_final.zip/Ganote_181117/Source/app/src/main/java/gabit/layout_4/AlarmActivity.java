package gabit.layout_4;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AlarmActivity extends Activity {
    AlertDialog.Builder mAlertDlgBuilder;
    AlertDialog mAlertDialog;
    View mDialogView = null;
    Button mOKBtn, mCancelBtn;
    TextView tv_title, tv_content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LayoutInflater inflater = getLayoutInflater();

        String title = getIntent().getBundleExtra("bundle").getString("title");
        String content = getIntent().getBundleExtra("bundle").getString("content");

        AlertDialog.Builder b=new AlertDialog.Builder(this);
        b.setTitle(title);
        b.setMessage(content);
        b.setPositiveButton("Ok", new DialogInterface. OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                finish();
            }});b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                dialog.dismiss();
                finish();
            }
        });
        b.create().show();
        // Build the dialog
//        mAlertDlgBuilder = new AlertDialog.Builder(this);
//        mDialogView = inflater.inflate(R.layout.alarm_dialog, null);
//
//        mOKBtn = (Button)mDialogView.findViewById(R.id.ID_Ok);
//        mCancelBtn = (Button)mDialogView.findViewById(R.id.ID_Cancel);
//        tv_title = (TextView) mDialogView.findViewById(R.id.alarm_dialog_title);
//        tv_content = (TextView) mDialogView.findViewById(R.id.alarm_dialog_content);
//
//        tv_title.setText(title);
//        tv_content.setText(content);
//        mOKBtn.setOnClickListener(mDialogbuttonClickListener);
//        mCancelBtn.setOnClickListener(mDialogbuttonClickListener);
//        mAlertDlgBuilder.setCancelable(false);
////        mAlertDlgBuilder.setInverseBackgroundForced(true);
//        mAlertDlgBuilder.setView(mDialogView);
//        mAlertDialog = mAlertDlgBuilder.create();
//        mAlertDialog.show();
    }

    View.OnClickListener mDialogbuttonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(v.getId() == R.id.ID_Ok)
            {
                mAlertDialog.dismiss();
//                finish();
//                Intent intent = new Intent(Intent.ACTION_MAIN);
//                intent.addCategory(Intent.CATEGORY_HOME);
//                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                startActivity(intent);
                finish();
//                System.exit(0);
            }
            else if(v.getId() == R.id.ID_Cancel)
            {
                mAlertDialog.dismiss();
//                finish();
//                Intent intent = new Intent(Intent.ACTION_MAIN);
//                intent.addCategory(Intent.CATEGORY_HOME);
//                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                startActivity(intent);
                finish();
//                System.exit(0);
            }
        }
    };
}
