package gabit.layout_4;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;

/**
 * Created by Marco on 11/18/2017.
 */

public class CustomEditText extends android.support.v7.widget.AppCompatEditText {
    private Paint paint = new Paint();

    public CustomEditText(Context context) {
        super(context);
        initPaint();
    }

    public CustomEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        initPaint();
    }

    public CustomEditText(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        initPaint();
    }

    private void initPaint(){
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.0f);
        paint.setColor(Color.BLACK);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int left = getLeft();
        int right = getRight();
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int height = getHeight();
        int lineHeight = getLineHeight();
        int count = (height-paddingTop-paddingBottom) / lineHeight;

        for (int i = 0; i < count; i++) {
            int baseline = lineHeight * (i+1) + paddingTop;
            canvas.drawLine(paddingLeft, baseline, right-paddingRight-left, baseline, paint);
        }
        super.onDraw(canvas);
    }
}
