package gabit.layout_4;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Marco on 11/18/2017.
 */

public class DataStorageUtils {

    public static void SaveData(Context context, List<Task> taskList){
        try{
            File f = new File("data.txt");
            if(f.exists()){
                f.delete();
            }
            FileOutputStream file_output = context.openFileOutput("data.txt", context.MODE_PRIVATE);
            OutputStreamWriter writer = new OutputStreamWriter(file_output);
            writer.write(taskList.size() + "\n");
            for(int i = 0; i < taskList.size(); i++){
                Task task = taskList.get(i);
                String str = task.getTitle() + "\n" +
                        task.getContent() + "\n" +
                        task.getDateTimeString() + "\n" +
                        task.isFinished() + "\n" +
                        task.isAlarm() + "\n";
                writer.write(str);
            }
            writer.close();
            Toast.makeText(context, "Data saved!", Toast.LENGTH_SHORT).show();
        } catch (Exception e){
            Toast.makeText(context, e.toString(), Toast.LENGTH_SHORT).show();
        }
    }

    public static List<Task> RestoreData(Context context){
        try{
            FileInputStream file_input = context.openFileInput("data.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(file_input));
            String str = "";
            List<Task> savedTaskList = new ArrayList<>();
            if ((str = reader.readLine()) != null){
                int num = Integer.parseInt(str + "");
                for(int i = 0; i < num ; i++)
                {
                    Task savedTask = new Task();
                    savedTask.setTitle(reader.readLine());
                    savedTask.setContent(reader.readLine());
                    savedTask.setDatetime(reader.readLine());
                    savedTask.setIsFinished(Boolean.parseBoolean(reader.readLine()));
                    savedTask.setAlarm(Boolean.parseBoolean(reader.readLine()));
                    savedTaskList.add(savedTask);
                }
            }
            reader.close();
            Toast.makeText(context, "Data restored", Toast.LENGTH_SHORT).show();
            return savedTaskList;
        } catch (Exception e) {
            AlertDialog.Builder b=new AlertDialog.Builder(context);
            b.setTitle("Error");
            b.setMessage(e.getMessage());
            b.setPositiveButton("Yes", new DialogInterface. OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    dialog.cancel();
                }});b.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    dialog.cancel();
                }
            });
            b.create().show();
            return null;
        }
    }
}
