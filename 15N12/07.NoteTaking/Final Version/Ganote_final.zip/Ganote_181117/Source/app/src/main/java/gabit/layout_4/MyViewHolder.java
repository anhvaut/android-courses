package gabit.layout_4;

import android.view.View;
import android.widget.CheckBox;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * Created by Marco on 10/28/2017.
 */

public class MyViewHolder {
    RelativeLayout layout;
    TextView title, contents, time;
    CheckBox finish, alarm;

    public MyViewHolder(View v) {
        this.layout = (RelativeLayout) v.findViewById(R.id.item_rlayout);
        this.title = (TextView) v.findViewById(R.id.item_title);
        this.contents = (TextView) v.findViewById(R.id.item_contents);
        this.time = (TextView) v.findViewById(R.id.item_date);
        this.finish = (CheckBox) v.findViewById(R.id.check_box);
        this.alarm = (CheckBox) v.findViewById(R.id.item_alarm);
    }
}
