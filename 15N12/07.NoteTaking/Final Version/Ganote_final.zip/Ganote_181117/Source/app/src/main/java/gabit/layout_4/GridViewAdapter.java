package gabit.layout_4;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Marco on 9/8/2017.
 */

public class GridViewAdapter extends ArrayAdapter<Task> {
    MyViewHolder holder;
    Colour colour = new Colour();

    public GridViewAdapter(@NonNull Context context, @LayoutRes int resource, @NonNull List<Task> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int postion, View convertView, ViewGroup parent){
        View v = convertView;
        if(v == null)
        {
            LayoutInflater inflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.grid_item, null);

        }
        Task task = getItem(postion);

        holder = new MyViewHolder(v);
        holder.layout.setBackgroundColor(colour.getColorLight());
        if (task.isFinished())
            holder.layout.setBackgroundColor(colour.getColorDark());
        else
            holder.layout.setBackgroundColor(colour.getColorLight());
        holder.title.setText(task.getTitle());
        holder.contents.setText(task.getContent());
        holder.time.setText(task.getDateTimeString());
        holder.finish.setChecked(task.isFinished());
        holder.alarm.setChecked(task.isAlarm());
        return v;
    }

    public void changeColor(Colour colour){
        this.colour = colour;
    }
}
