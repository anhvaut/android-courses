package gabit.layout_4;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.support.annotation.NonNull;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ActionBarDrawerToggle drawerToggle;
    private DrawerLayout drawerLayout;
    private ViewStub stubGrid;
    private ViewStub stubList;
    private ListView listView;
    private GridView gridView;
    private ListViewAdapter listViewAdapter;
    private GridViewAdapter gridViewAdapter;
    private List<Task> taskList = new ArrayList<>();
    private int currentViewMode = 0;
    private int currentColor = 0;
    private boolean currentAlarm = true;
    private ImageButton btn_input_list;
    private ImageButton btn_input_grid;
    private Button test_btn, test_btn_2, test_btn_3;
    private AlarmTask alarmTask;
    private AlarmManager alarmManager;
    private Intent alarmIntent;
    private PendingIntent pendingIntent;
    private Colour myColour;

    static final int VIEW_MODE_LISTVIEW = 0;
    static final int VIEW_MODE_GRIDVIEW = 1;
    public static final int REQUEST_CODE_INPUT = 110;
    public static final int REQUEST_CODE_EDIT = 100;
    public static final int RESULT_CODE_EDIT_SUBMIT = 101;
    public static final int RESULT_CODE_EDIT_CANCEL = 102;
    public static final int RESULT_CODE_INPUT_SUBMIT = 111;
    public static final int RESULT_CODE_INPUT_CANCEL = 112;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        PushNotifiUtils.create(this);
        getFormWidgets();
        setDefaultInfor();
        taskList = DataStorageUtils.RestoreData(this);
        switchView();
    }

    private void getFormWidgets()
    {


        Toast t = Toast.makeText(MainActivity.this, "Hello!!!", Toast.LENGTH_LONG);
        t.show();

        myColour = new Colour();

        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmIntent = new Intent(MainActivity.this, AlarmReceiver.class);
        //pendingIntent = PendingIntent.getBroadcast(this, 0, alarmIntent, 0);
        alarmTask = new AlarmTask(this, taskList);

        drawerLayout = (DrawerLayout) findViewById(R.id.activity_main_drawer);
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(drawerToggle);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        stubList = (ViewStub) findViewById(R.id.stub_list);
        stubGrid = (ViewStub) findViewById(R.id.stub_grid);
        stubList.inflate();
        stubGrid.inflate();
        listView = (ListView) findViewById(R.id.mylistview);
        gridView = (GridView) findViewById(R.id.mygridview);

        btn_input_list = (ImageButton) findViewById(R.id.add_button_list);
        btn_input_grid = (ImageButton) findViewById(R.id.add_button_grid);
        test_btn = (Button) findViewById(R.id.test_btn);
        test_btn_2 = (Button) findViewById(R.id.test_btn_2);
        test_btn_3 = (Button) findViewById(R.id.test_btn_3);
    }

    private void setDefaultInfor(){
        test_btn.setOnClickListener(setAlarm);
        test_btn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                taskList = DataStorageUtils.RestoreData(MainActivity.this);
                notifyDataChanged();
            }
        });
        test_btn_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DataStorageUtils.SaveData(MainActivity.this, taskList);
            }
        });
        btn_input_list.setOnClickListener(inputClick);
        btn_input_grid.setOnClickListener(inputClick);
        listView.setOnItemClickListener(itemClick);
        listView.setOnItemLongClickListener(longItemClick);
        gridView.setOnItemClickListener(itemClick);
        gridView.setOnItemLongClickListener(longItemClick);
        SharedPreferences sharedPreferences = getSharedPreferences("ViewMode", MODE_PRIVATE);
        currentViewMode = sharedPreferences.getInt("currentViewMode", VIEW_MODE_LISTVIEW);
        sharedPreferences = getSharedPreferences("BGD_COLOR", MODE_PRIVATE);
        int savedColor = sharedPreferences.getInt("CurrentColor", Colour.HOLO_GREEN_LIGHT);
        myColour.setCurrentColorMode(savedColor);
    }

    // Ham chuyen doi view va dat adapter cho tung view
    private void switchView(){
        if (VIEW_MODE_LISTVIEW == currentViewMode){
            stubList.setVisibility(View.VISIBLE);
            stubGrid.setVisibility(View.GONE);
        } else{
            stubList.setVisibility(View.GONE);
            stubGrid.setVisibility(View.VISIBLE);
        }
        setAdapters();
    }

    // Ham dat adapter cho tung view
    private  void setAdapters(){
        if (VIEW_MODE_LISTVIEW == currentViewMode){
            listViewAdapter = new ListViewAdapter(this, R.layout.list_item, taskList){
                @NonNull
                @Override
                public View getView (final int position, View convertView, ViewGroup parent)
                {
                    View v = super.getView(position, convertView, parent);

                    ImageButton delete_btn = (ImageButton) v.findViewById(R.id.delete_button_list);
                    delete_btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            // TODO Auto-generated method stub
                            taskList.remove(position);
                            listViewAdapter.notifyDataSetChanged();
                        }
                    });

                    CheckBox checkBox = (CheckBox) v.findViewById(R.id.check_box);
                    checkBox.setTag(position);
                    checkBox.setOnClickListener(checkBox_listener);

                    CheckBox alarm = (CheckBox) v.findViewById(R.id.item_alarm);
                    alarm.setTag(position);
                    alarm.setChecked(taskList.get(position).isAlarm() && currentAlarm);
                    alarm.setOnClickListener(toggleAlarm);
                    return v;
                }
            };
            listView.setAdapter(listViewAdapter);
            listViewAdapter.changeColor(myColour);
        } else{
            gridViewAdapter = new GridViewAdapter(this, R.layout.grid_item, taskList){
                @NonNull
                @Override
                public View getView (final int position, View convertView, ViewGroup parent)
                {
                    View v = super.getView(position, convertView, parent);

                    ImageButton delete_btn = (ImageButton) v.findViewById(R.id.delete_button_grid);
                    delete_btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            // TODO Auto-generated method stub
                            taskList.remove(position);
                            gridViewAdapter.notifyDataSetChanged();
                        }
                    });

                    CheckBox checkBox = (CheckBox) v.findViewById(R.id.check_box);
                    checkBox.setTag(position);
                    checkBox.setOnClickListener(checkBox_listener);

                    CheckBox alarm = (CheckBox) v.findViewById(R.id.item_alarm);
                    alarm.setTag(position);
                    alarm.setChecked(taskList.get(position).isAlarm() && currentAlarm);
                    alarm.setOnClickListener(toggleAlarm);

                    return v;
                }
            };
            gridView.setAdapter(gridViewAdapter);
            gridViewAdapter.changeColor(myColour);
        }
    }

    View.OnClickListener setAlarm = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            alarmTask.setAlarm();
        }
    };

    View.OnClickListener cancelAlarm = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            alarmTask.cancelAll();
        }
    };

    View.OnClickListener toggleAlarm = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int pos = (Integer) v.getTag();
            taskList.get(pos).setAlarm(!(taskList.get(pos).isAlarm()));
            notifyDataChanged();
        }
    };

    View.OnClickListener inputClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent intent = new Intent(MainActivity.this, input_activity.class);
            intent.putExtra("requestCode", REQUEST_CODE_INPUT);
            intent.putExtra("colorCode", myColour.getCurrentColorMode());
            startActivityForResult(intent, REQUEST_CODE_INPUT);
        }
    };

    AdapterView.OnItemLongClickListener longItemClick = new AdapterView.OnItemLongClickListener() {
        @Override
        public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
            editTask(i);
            return false;
        }
    };

    AdapterView.OnItemClickListener itemClick = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, final int i, long l) {
            AlertDialog.Builder b=new AlertDialog.Builder(MainActivity.this);
            b.setTitle(taskList.get(i).getTitle());
            b.setMessage(taskList.get(i).getContent());
            b.setPositiveButton("Yes", new DialogInterface. OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    editTask(i);
                }});b.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    dialog.cancel();
                }
            });
            b.create().show();
        }
    };

    View.OnClickListener checkBox_listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            int pos = (Integer) view.getTag();
            //Toast.makeText(MainActivity.this, pos, Toast.LENGTH_SHORT).show();
            boolean isFinished = !(taskList.get(pos).isFinished());
            taskList.get(pos).setIsFinished(isFinished);
            Task task = taskList.get(pos);
            taskList.remove(pos);
            if(isFinished){
                taskList.add(task);
            }
            else{
                taskList.add(0, task);
            }
            notifyDataChanged();
        }
    };

    // Ham tao menu
    @Override
    public  boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.switch_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // Xu ly khi click vao menu
    @Override
    public  boolean onOptionsItemSelected(MenuItem item){
        if(drawerToggle.onOptionsItemSelected(item)) {
            return true;
        }

        switch (item.getItemId()){
            case R.id.menu_add_item: {
                Intent intent = new Intent(MainActivity.this, input_activity.class);
                intent.putExtra("requestCode", REQUEST_CODE_INPUT);
                intent.putExtra("colorCode", myColour.getCurrentColorMode());
                startActivityForResult(intent, REQUEST_CODE_INPUT);
                break;
            }
            case R.id.menu_item_switch:{
                if(VIEW_MODE_LISTVIEW == currentViewMode){
                    currentViewMode = VIEW_MODE_GRIDVIEW;
                } else{
                    currentViewMode = VIEW_MODE_LISTVIEW;
                }
                switchView();
                SharedPreferences sharedPreferences = getSharedPreferences("ViewMode", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("CurrentViewMode", currentViewMode);
                editor.commit();
                break;
            }
            case R.id.search:
                Toast.makeText(this, "Search button selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.about:
                Toast.makeText(this, "About button selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.help:
                Toast.makeText(this, "Help button selected", Toast.LENGTH_SHORT).show();
                return true;
        }
        return true;
    }

    // Xu ly ket qua tra ve tu man hinh nhap
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent){
        super.onActivityResult(requestCode, resultCode, intent);

        if(requestCode == REQUEST_CODE_INPUT)
        {
            if(resultCode == MainActivity.RESULT_CODE_INPUT_SUBMIT)
            {
                Task newTask = (Task) intent.getBundleExtra("inputBundle").getSerializable("newTask");
                taskList.add(newTask);
                Toast toast = Toast.makeText(MainActivity.this, "New task added: " + taskList.size(), Toast.LENGTH_LONG);
                toast.show();
            }
            if(resultCode == MainActivity.RESULT_CODE_EDIT_SUBMIT){
                int index = intent.getIntExtra("index", 0);
                Task newTask = (Task) intent.getBundleExtra("inputBundle").getSerializable("newTask");
                taskList.remove(index);
                taskList.add(index, newTask);
            }
        }
        else {
            Toast toast = Toast.makeText(MainActivity.this, "Intent error!!!", Toast.LENGTH_LONG);
            toast.show();
        }
        // Cap nhat lai view sau khi thay doi du lieu
        notifyDataChanged();
    }

    private void notifyDataChanged()
    {
        if(VIEW_MODE_LISTVIEW == currentViewMode)
            listViewAdapter.notifyDataSetChanged();
        else
            gridViewAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        drawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        drawerToggle.onConfigurationChanged(newConfig);
    }

    public void editTask(int position){
        Intent intent = new Intent(MainActivity.this, input_activity.class);
        intent.putExtra("requestCode", REQUEST_CODE_EDIT);
        intent.putExtra("index", position);
        intent.putExtra("colorCode", myColour.getCurrentColorMode());
        Bundle bundle = new Bundle();
        bundle.putSerializable("task", taskList.get(position));
        intent.putExtra("taskBundle", bundle);
        startActivityForResult(intent, REQUEST_CODE_INPUT);
    }

    public void ChangeColor(View view){
        myColour.nextColor();
        if (currentViewMode == VIEW_MODE_LISTVIEW)
            listViewAdapter.changeColor(myColour);
        else
            gridViewAdapter.changeColor(myColour);
        notifyDataChanged();
        SharedPreferences sharedPreferences = getSharedPreferences("BGD_COLOR", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("CurrentColor", myColour.getCurrentColorMode());
        editor.commit();
        drawerLayout.closeDrawers();
    }

    public void ToggleAlarm(View view){
        currentAlarm = !currentAlarm;
        drawerLayout.closeDrawers();
    }

    @Override
    protected void onDestroy() {
        DataStorageUtils.SaveData(this, taskList);
        super.onDestroy();
    }
}
