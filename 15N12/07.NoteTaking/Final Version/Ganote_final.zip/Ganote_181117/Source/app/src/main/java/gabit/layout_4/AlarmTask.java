package gabit.layout_4;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.os.SystemClock;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Marco on 11/3/2017.
 */

public class AlarmTask {
    private List<Task> taskList;
    private AlarmManager alarmManager;
    private Intent alarmIntent;
    private Context context;
    private List<Integer> alarmID;
    private boolean alarmON, toggleON;

    public AlarmTask(Context context, List<Task> taskList) {
        this.taskList = taskList;
        alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmIntent = new Intent(context, AlarmReceiver.class);
        this.context = context;
        alarmID = new ArrayList<>();
        alarmON = false;
    }

    public void setAlarm(){

        cancelAll();
        String time = "";
        for(int i = 0; i < taskList.size(); i++){
            Task task = taskList.get(i);

            if (task.isAlarm() && !task.isFinished()) {
                Bundle bundle = new Bundle();
                bundle.putString("title", task.getTitle());
                bundle.putString("content", task.getContent());
                alarmIntent.putExtra("bundle", bundle);


                Calendar calendar = Calendar.getInstance();
                calendar.setTime(task.getTime());

                long timeInMilis = calendar.getTimeInMillis();
                int aID = (int) System.currentTimeMillis();
                alarmID.add(aID);
                PendingIntent pending = PendingIntent.getBroadcast(context, aID, alarmIntent, 0);
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeInMilis, pending);
                time += i + calendar.toString();
            }
        }
        AlertDialog.Builder b=new AlertDialog.Builder(this.context);
        b.setTitle("ALARM");
        b.setMessage(time);
        b.setPositiveButton("Ok", new DialogInterface. OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
//                finish();
            }});b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
//                dialog.dismiss();
//                finish();
            }
        });
        b.create().show();
        alarmON = true;
    }

    public void cancelAll() {
        if(alarmON)
        for(int i = 0; i < alarmID.size(); i++){
            PendingIntent pending = PendingIntent.getBroadcast(context, alarmID.get(i), alarmIntent, 0);
            alarmManager.cancel(pending);
        }
        alarmID.clear();
        alarmON =false;
    }

    public void cancel(Task task) {

    }



    public boolean isAlarmON() {
        return alarmON;
    }

    public boolean isToggleON() {
        return toggleON;
    }

    public void setToggleON(boolean toggleON) {
        this.toggleON = toggleON;
    }
}
