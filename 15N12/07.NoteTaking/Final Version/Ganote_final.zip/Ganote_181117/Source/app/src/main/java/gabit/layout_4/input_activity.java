package gabit.layout_4;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.icu.util.Calendar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by Marco on 9/9/2017.
 */

public class input_activity extends AppCompatActivity {

    private ImageButton btnCallMainActivity;
    private Button btn_date, btn_time, btn_submit;
    private Calendar calendar;
    private Date timeFinish;
    private CheckBox checkBox;
    private EditText edit_title, edit_contents;
    private String title = "No title", contents = "No content";
    private int mode, index;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.input_layout);

        mode = this.getIntent().getIntExtra("requestCode", MainActivity.REQUEST_CODE_INPUT);
        Colour colour = new Colour();
        colour.setCurrentColorMode(this.getIntent().getIntExtra("colorCode", 0));
        RelativeLayout input_layout = (RelativeLayout) findViewById(R.id.input_layout);
        input_layout.setBackgroundColor(colour.getColorLight());

        getFormWidgets();
        if(mode == MainActivity.REQUEST_CODE_INPUT)
            setDefaultInfor();
        if(mode == MainActivity.REQUEST_CODE_EDIT){
            Task task = (Task) this.getIntent().getBundleExtra("taskBundle").getSerializable("task");
            setDefaultInfor(task);
        }
        addEventFormWidgets();

        btnCallMainActivity = (ImageButton) findViewById(R.id.cancel_input_button);
        btnCallMainActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = input_activity.this.getIntent();
                if(mode == MainActivity.REQUEST_CODE_INPUT)
                    setResult(MainActivity.RESULT_CODE_INPUT_CANCEL, intent);
                if(mode == MainActivity.REQUEST_CODE_EDIT)
                    setResult(MainActivity.RESULT_CODE_EDIT_CANCEL, intent);
                finish();
            }
        });
    }

    public void getFormWidgets(){
        // Load cac control theo id

        checkBox = (CheckBox) findViewById(R.id.chbox_alarm);
        btn_date = (Button) findViewById(R.id.date_button);
        btn_time = (Button) findViewById(R.id.time_button);
        btn_submit = (Button) findViewById(R.id.button_submit);
        edit_title = (EditText) findViewById(R.id.editTitle);
        edit_contents = (EditText) findViewById(R.id.editContent);
    }

    public void setDefaultInfor(Task task){
        calendar = Calendar.getInstance();
        edit_title.setText(task.getTitle());
        edit_contents.setText(task.getContent());
        // Dinh dang ngay va hien thi len giao dien
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String strDate = sdf.format(task.getTime());
        btn_date.setText(strDate);

        // Dinh dang gio va hien thi len giao dien
        sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        String strTime = sdf.format(task.getTime());
        btn_time.setText(strTime);

        // Lay gio theo 24h de lap trinh theo tag
        sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        btn_time.setTag(sdf.format(task.getTime()));

        edit_title.requestFocus();

        // Gan cal.getTime() cho ngay/gio hoan thanh
        timeFinish  = task.getTime();
    }
    public void setDefaultInfor(){
        // Lay ngay hien tai cua he thong
        calendar = Calendar.getInstance();

        // Dinh dang ngay va hien thi len giao dien
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String strDate = sdf.format(calendar.getTime());
        btn_date.setText(strDate);

        // Dinh dang gio va hien thi len giao dien
        sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        String strTime = sdf.format(calendar.getTime());
        btn_time.setText(strTime);

        // Lay gio theo 24h de lap trinh theo tag
        sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        btn_time.setTag(sdf.format(calendar.getTime()));;

        edit_title.requestFocus();

        // Gan cal.getTime() cho ngay/gio hoan thanh
        timeFinish  = calendar.getTime();
    }

    public void addEventFormWidgets(){
        btn_date.setOnClickListener(new MyButtonEvent());
        btn_time.setOnClickListener(new MyButtonEvent());
        btn_submit.setOnClickListener(new MyButtonEvent());
    }

    private  class MyButtonEvent implements View.OnClickListener {
        @Override
        public void onClick(View v){
            switch (v.getId()){
                case R.id.date_button:
                    showDatePickerDialog();
                    break;
                case R.id.time_button:
                    showTimePickerDialog();
                    break;
                case R.id.button_submit:
                    submitNewTask(MainActivity.RESULT_CODE_INPUT_SUBMIT);
                    break;
            }
        }
    }

    public void showDatePickerDialog(){
        DatePickerDialog.OnDateSetListener callback = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                btn_date.setText(i2 + "/" + (i1+1) + "/" + i);
                calendar.set(i, i1, i2);
                timeFinish = calendar.getTime();
            }
        };

        String s = btn_date.getText() + "";
        String strArrtmp[]=s.split("/");
        int ngay = Integer.parseInt(strArrtmp[0]);
        int thang = Integer.parseInt(strArrtmp[1]) - 1;
        int nam = Integer.parseInt(strArrtmp[2]);
        DatePickerDialog pic=new DatePickerDialog(
                input_activity.this,
                callback, nam, thang, ngay);
        pic.setTitle("Choose date to finish");
        pic.show();
    }

    public void showTimePickerDialog(){
        TimePickerDialog.OnTimeSetListener callback = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int i, int i1) {
                String s = i + ":" + i1;
                int hourTam=i;
                if(hourTam>12)
                    hourTam=hourTam-12;
                btn_time.setText(hourTam + ":"+ i1 +(i>12?" PM":" AM"));
                //lưu giờ thực vào tag
                btn_time.setTag(s);
                //lưu vết lại giờ vào hourFinish
                calendar.set(Calendar.HOUR_OF_DAY, i);
                calendar.set(Calendar.MINUTE, i1);
                timeFinish=calendar.getTime();
            }
        };
        //TimePickerDialog t = new TimePickerDialog(input_activity.this, callback, 1, 1, true);
        //t.show();

        //các lệnh dưới này xử lý ngày giờ trong TimePickerDialog
        //sẽ giống với trên TextView khi mở nó lên

        String s= btn_time.getTag() + "";
        String strArr[]=s.split(":");
        int h = Integer.parseInt(strArr[0]);
        int m = Integer.parseInt(strArr[1]);
        TimePickerDialog time=new TimePickerDialog(
                input_activity.this,
                callback, h, m, true);
        time.setTitle("Choose time to finish");
        time.show();
    }

    public void submitNewTask(int resultCode){
        title = edit_title.getText() + "";
        contents = edit_contents.getText() + "";

        Intent returnIntent = input_activity.this.getIntent();
        Bundle inputBundle = new Bundle();
        Task newTask = new Task(title, contents,timeFinish, false,checkBox.isChecked());
        inputBundle.putSerializable("newTask", newTask);
        returnIntent.putExtra("inputBundle", inputBundle);
        if(mode == MainActivity.REQUEST_CODE_INPUT)
            setResult(MainActivity.RESULT_CODE_INPUT_SUBMIT, returnIntent);
        if(mode == MainActivity.REQUEST_CODE_EDIT){
            returnIntent.putExtra("index", this.getIntent().getIntExtra("index", 0));
            setResult(MainActivity.RESULT_CODE_EDIT_SUBMIT, returnIntent);
        }
        finish();
    }
}
