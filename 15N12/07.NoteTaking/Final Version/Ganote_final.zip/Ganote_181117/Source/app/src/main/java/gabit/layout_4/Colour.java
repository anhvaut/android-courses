package gabit.layout_4;

import android.support.v4.content.ContextCompat;

/**
 * Created by Marco on 11/1/2017.
 */

public class Colour {
    public static final int HOLO_BLUE_LIGHT = 0xff33b5e5;
    public static final int HOLO_BLUE_DARK = 0xff0099cc;
    public static final int HOLO_BLUE_BRIGHT = 0xff00ddff;
    public static final int HOLO_GREEN_LIGHT = 0xff99cc00;
    public static final int HOLO_GREEN_DARK = 0xff669900;
    public static final int HOLO_RED_LIGHT = 0xffff4444;
    public static final int HOLO_RED_DARK = 0xffcc0000;
    public static final int HOLO_ORANGE_LIGHT = 0xffffbb33;
    public static final int HOLO_ORANGE_DARK = 0xffff8800;

    int color;

    public Colour(){
        this.color = 0;
    }

    public int getColorLight() {
        switch (color) {
            case 0:
                return HOLO_GREEN_LIGHT;
            case 1:
                return HOLO_BLUE_LIGHT;
            case 2:
                return HOLO_ORANGE_LIGHT;
            case 3:
                return HOLO_RED_LIGHT;
            default:
                color = 0;
                return HOLO_GREEN_LIGHT;
        }
    }

    public int getColorDark() {
        switch (color) {
            case 0:
                return HOLO_GREEN_DARK;
            case 1:
                return HOLO_BLUE_DARK;
            case 2:
                return HOLO_ORANGE_DARK;
            case 3:
                return HOLO_RED_DARK;
            default:
                color = 0;
                return HOLO_GREEN_DARK;
        }
    }

    public void nextColor() {
        color = (color + 1) % 4;
    }

    public void previousColor() {
        color = (color - 1) % 4;
    }

    public int getCurrentColorMode() {
        return color;
    }

    public void setCurrentColorMode(int color) {
        this.color = color;
    }
}
