package com.example.hoangcongtuan.quanlylichhoc.adapter;

/**
 * Created by hoangcongtuan on 9/8/17.
 * call back khi nguoi dung keo bang tin xuong, se load them tin moi
 */

public interface OnLoadMoreListener {
    void onLoadMore();
}
