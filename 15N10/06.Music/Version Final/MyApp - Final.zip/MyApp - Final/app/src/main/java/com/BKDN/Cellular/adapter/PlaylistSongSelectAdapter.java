package com.BKDN.Cellular.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.BKDN.Cellular.R;
import com.BKDN.Cellular.object.Song;

import java.util.List;

/**
 * Created by Administrator on 10/25/2017.
 */

public class PlaylistSongSelectAdapter extends BaseAdapter {
    private Context mcontext;
    private int layout;
    private List<Song> mSongList;
    private int[] mSonglistSelect;
    public PlaylistSongSelectAdapter(Context mcontext, int layout, List<Song> mSongList) {
        this.mcontext = mcontext;
        this.layout = layout;
        this.mSongList = mSongList;
    }

    public PlaylistSongSelectAdapter(Context mcontext, int layout, List<Song> mSongList, int[] mSonglistSelect) {
        this.mcontext = mcontext;
        this.layout = layout;
        this.mSongList = mSongList;
        this.mSonglistSelect = mSonglistSelect;
    }

    @Override
    public int getCount() {
        return mSongList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    private class ViewHolder {
        TextView tvNameSong;
        TextView tvTimeSong;
        ImageView imgSelect;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        final PlaylistSongSelectAdapter.ViewHolder viewHolder;
        if (view == null) {
            final LayoutInflater inflater = (LayoutInflater) mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(layout, null);
            viewHolder = new PlaylistSongSelectAdapter.ViewHolder();
            viewHolder.tvNameSong = (TextView) view.findViewById(R.id.tv_name_song_select);
            viewHolder.tvTimeSong = (TextView) view.findViewById(R.id.tv_time_song_select);
            viewHolder.imgSelect= (ImageView) view.findViewById(R.id.img_song_select);
            view.setTag(viewHolder);
        } else {
            viewHolder = (PlaylistSongSelectAdapter.ViewHolder) view.getTag();
        }
        final Song mSong = mSongList.get(i);
        viewHolder.tvNameSong.setText(mSong.getmNameSong().toString());
        viewHolder.tvTimeSong.setText(mSong.getmTimeSong() + "");

        final int index=i;
        viewHolder.imgSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mSonglistSelect[index]=(mSonglistSelect[index]==0?1:0);
                if(mSonglistSelect[index]==1) viewHolder.imgSelect.setBackgroundResource(R.drawable.ic_song_selected);
                if(mSonglistSelect[index]==0) viewHolder.imgSelect.setBackgroundResource(R.drawable.ic_song_select);

            }
        });

        return view;
    }

    @Override
    public CharSequence[] getAutofillOptions() {
        return new CharSequence[0];
    }
}
