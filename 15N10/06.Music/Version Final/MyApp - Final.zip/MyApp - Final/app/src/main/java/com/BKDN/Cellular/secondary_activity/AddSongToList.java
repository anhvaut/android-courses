package com.BKDN.Cellular.secondary_activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.BKDN.Cellular.PlaylistActivity;
import com.BKDN.Cellular.R;
import com.BKDN.Cellular.adapter.PlaylistSongSelectAdapter;

public class AddSongToList extends AppCompatActivity {

    private ListView lvPlaylistAddSong;
    //private ArrayList<Song> songArrayListAddTolayList;
    private EditText edtPlaylistName;
    private int[] mListSelect=new int[PlaylistActivity.mSongList.size()];
    PlaylistSongSelectAdapter playlistSongSelectAdapter;

    Button btnAddPlaylistOK;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_song_to_list);

        init();
        click();

    }

    private void click() {
        lvPlaylistAddSong.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
               // mListSelect[i]=mListSelect[i]==1?0:1;
                if (mListSelect[i]==1 ) mListSelect[i]=0;
                else mListSelect[i]=1;
            }
        });

        btnAddPlaylistOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!edtPlaylistName.getText().toString().isEmpty()){
                    for (int i=0;i<PlaylistActivity.mSongList.size();i++){
                        if (mListSelect[i]==1)
                        {
//                            String name=PlaylistActivity.mSongList.get(i).getmNameSong();
//                            String path= PlaylistActivity.mSongList.get(i).getmPathSong();
//                            String duration=PlaylistActivity.mSongList.get(i).getmNameSong();
//                            PlaylistActivity.myDatabase.QueryData("INSERT INTO Playlist VALUES(null,'"+edtPlaylistName.getText().toString()+"','"+name+"','"+path+"','"+duration+"')");

                            String name=edtPlaylistName.getText().toString();
                            int id=PlaylistActivity.mSongList.get(i).getmSongId();
                            PlaylistActivity.myDatabase.QueryData("INSERT INTO Playlist VALUES(null,'"+name+"','"+id+"')");

                        }
                    }
                    for (int i=0;i<mListSelect.length;i++) mListSelect[i]=0;
                    Toast.makeText(AddSongToList.this, "Da xong", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(AddSongToList.this,PlaylistActivity.class));
                }
                else Toast.makeText(AddSongToList.this, "Chưa nhập đủ rồi", Toast.LENGTH_SHORT).show();


            }
        });

    }

    private void init() {

        edtPlaylistName= (EditText) findViewById(R.id.edtPlaylistName);
        lvPlaylistAddSong= (ListView) findViewById(R.id.lvPlaylistAddSong);
        btnAddPlaylistOK= (Button) findViewById(R.id.btnAddPlaylistOK);

        for (int i=0;i<PlaylistActivity.mSongList.size();i++){
            mListSelect[i]=0;
        }
        playlistSongSelectAdapter=new PlaylistSongSelectAdapter(this,R.layout.item_activity_list_song_select,PlaylistActivity.mSongList,mListSelect);
        lvPlaylistAddSong.setAdapter(playlistSongSelectAdapter);



    }
}
