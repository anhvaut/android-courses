/*
package com.BKDN.Cellular;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.BKDN.Cellular.MusicService.MusicBinder;

import java.io.IOException;
import java.util.ArrayList;

import static com.BKDN.Cellular.PlaylistActivity.sSonglistCopy;
import static com.BKDN.Cellular.R.drawable.ic_pause;

public class MusicActivity extends AppCompatActivity {

    private Button btnReturn, btnPlayPause;
    private TextView tvTenBaiHat;

    //25/9
    private MusicService musicSrv;
    private Intent playIntent;
    private boolean musicBound=false;

    public static int position2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);

        anhXa();

        clickView();


        //playBaiHat();


        //25/9
        play();
        //songPicked();

    }
    private ServiceConnection musicConnection = new ServiceConnection(){

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MusicService.MusicBinder binder = (MusicService.MusicBinder)service;
            //get service
            musicSrv = binder.getService();
            //pass list
            musicSrv.setList(sSonglistCopy);
            musicBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            musicBound = false;
        }
    };
    private void play() {
        //connect to the service

    }

    private void clickView() {
        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MusicActivity.this, PlaylistActivity.class);
                startActivity(intent);
            }
        });

    }

    private void anhXa() {

        btnReturn = (Button) findViewById(R.id.btn_return);
        btnPlayPause = (Button) findViewById(R.id.btn_play);
        tvTenBaiHat = (TextView) findViewById(R.id.tv_song);
    }

    public void playBaiHat() {
        Intent intent = getIntent();
        int position = intent.getIntExtra("TransSong", -1);
        if (position != -1) {
            Song mSong = sSonglistCopy.get(position);
            MediaPlayer mediaPlayer = new MediaPlayer();
            try {
                mediaPlayer.setDataSource(mSong.getmPathSong());
                tvTenBaiHat.setText(mSong.getmNameSong().toString());
                btnPlayPause.setBackgroundResource(R.drawable.ic_pause);
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                mediaPlayer.prepare();
            } catch (IOException e) {
                e.printStackTrace();
            }
            mediaPlayer.start();

        }

    }
    @Override
    protected void onStart() {
        super.onStart();
        Intent intent = getIntent();
        int position2 = intent.getIntExtra("TransSong", -1);
        if(playIntent==null){
            playIntent = new Intent(this, MusicService.class);

            bindService(playIntent, musicConnection, Context.BIND_AUTO_CREATE);
            startService(playIntent);
           // songPicked();
        }
    }
    //public void songPicked(View view){
    public void songPicked(){
        //musicSrv.setSong(Integer.parseInt(view.getTag().toString()));




        if (position2!=-1){
            musicSrv.setSong(position2);
            musicSrv.playSong();
        }
        else Toast.makeText(musicSrv, "Hix", Toast.LENGTH_SHORT).show();




    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //menu item selected
        switch (item.getItemId()) {
            case R.id.btn_random:
                //shuffle
                break;
            case R.id.btn_repeat:
                stopService(playIntent);
                musicSrv=null;
                System.exit(0);
                break;
        }
        return super.onOptionsItemSelected(item);
    }


}
*/
