package com.BKDN.Cellular.adapterRecycleView;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.BKDN.Cellular.fragment.NoteFragment;
import com.BKDN.Cellular.fragment.PlaylistFragment;
import com.BKDN.Cellular.fragment.SongFragment;

/**
 * Created by Administrator on 10/27/2017.
 */

public class PagerAdapter extends FragmentStatePagerAdapter {
    int mNumOfTabs;

    public PagerAdapter(FragmentManager fm, int NumOfTabs) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
    }
    @Override
    public Fragment getItem(int position) {

        switch (position) {
            case 0:
                NoteFragment tab1 = new NoteFragment();

                return tab1;
            case 1:
                SongFragment tab2 = new SongFragment();
                return tab2;
            case 2:
                PlaylistFragment tab3 = new PlaylistFragment();
                return tab3;
            /*case 3:
                AlbumFragment tab4 = new AlbumFragment();
                return tab4;*/
            default:
                return null;
        }
    }
    @Override
    public int getCount() {
        return mNumOfTabs;
    }



}
