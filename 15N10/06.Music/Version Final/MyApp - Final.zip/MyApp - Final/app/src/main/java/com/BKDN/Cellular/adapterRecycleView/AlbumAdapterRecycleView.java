package com.BKDN.Cellular.adapterRecycleView;

import android.app.Dialog;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.BKDN.Cellular.R;
import com.BKDN.Cellular.object.Album;

import java.util.ArrayList;

/**
 * Created by Administrator on 10/27/2017.
 */

public class AlbumAdapterRecycleView extends RecyclerView.Adapter<AlbumAdapterRecycleView.Viewholder>{

    ArrayList<Album> albumArraylist;
    Context context;

    public AlbumAdapterRecycleView(ArrayList<Album> albumArraylist, Context context) {
        this.albumArraylist = albumArraylist;
        this.context = context;
    }

    @Override
    public Viewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View itemView=layoutInflater.inflate(R.layout.item_activity_list_album,parent,false);
        return new Viewholder(itemView);
    }

    @Override
    public void onBindViewHolder(Viewholder holder, int position) {
        holder.tvAlbumName.setText(albumArraylist.get(position).getmAlbumName());
       // holder.tvSongDuration.setText(albumArraylist.get(position).getmAlbumSize());

    }

    @Override
    public int getItemCount() {
        return albumArraylist.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        TextView tvAlbumName;
        TextView tvSongDuration;
        ImageView imgAlbumOption;

        public Viewholder(final View itemView) {
            super(itemView);
            tvAlbumName= (TextView) itemView.findViewById(R.id.tv_album_name);
            tvSongDuration= (TextView) itemView.findViewById(R.id.tv_num_of_song_on_album);
            imgAlbumOption= (ImageView) itemView.findViewById(R.id.imgAlbumOption);

            imgAlbumOption.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Dialog dialog = new Dialog(view.getContext());
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    dialog.setContentView(R.layout.custom_item_album);
                    dialog.show();
                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(itemView.getContext(), "vị trí "+ getAdapterPosition(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}



















