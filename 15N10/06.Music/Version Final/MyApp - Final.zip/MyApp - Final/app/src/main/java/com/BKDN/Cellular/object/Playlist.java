package com.BKDN.Cellular.object;

import java.util.ArrayList;

/**
 * Created by Administrator on 9/8/2017.
 */

public class Playlist {
    private String mPlaylistName;
    private int mPlaylistSize;
    private ArrayList<Song> playlistListSong;

    public Playlist(String mPlaylistName, ArrayList<Song> playlistListSong) {
        this.mPlaylistName = mPlaylistName;
        this.playlistListSong = playlistListSong;
        this.mPlaylistSize=playlistListSong.size();
    }
    public ArrayList<Song> getPlaylistListSong() {
        return playlistListSong;
    }
    public String getmPlaylistName() {
        return mPlaylistName;
    }
    public int getmPlaylistSize() {
        return playlistListSong.size();
    }
    @Override
    public String toString() {
        return "Playlist{" +
                "mPlaylistName='" + mPlaylistName + '\'' +
                ", mIconPlaylist=" +
                ", mPlaylistSize=" + mPlaylistSize +
                '}';
    }
}
