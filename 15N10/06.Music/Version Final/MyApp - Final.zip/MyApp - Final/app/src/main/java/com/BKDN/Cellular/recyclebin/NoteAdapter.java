package com.BKDN.Cellular.recyclebin;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.BKDN.Cellular.R;
import com.BKDN.Cellular.object.Note;
import com.BKDN.Cellular.secondary_activity.MusicActivity;

import java.util.List;

/**
 * Created by Administrator on 9/9/2017.
 */

public class NoteAdapter extends BaseAdapter {

    private Context mcontext;
    private int layout;
    private List<Note> noteList;

    public NoteAdapter(Context mcontext, int layout, List<Note> noteList) {
        this.mcontext = mcontext;
        this.layout = layout;
        this.noteList = noteList;
    }

    @Override
    public int getCount() {
        return noteList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        final LayoutInflater inflater = (LayoutInflater) mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(layout, null);
        final TextView tvFeelOnday = (TextView) view.findViewById(R.id.tv_note_name);
        TextView tvFeelDate = (TextView) view.findViewById(R.id.tv_note_date);

        Note mNote = noteList.get(i);

        tvFeelOnday.setText(mNote.getmNoteName().toString());
        tvFeelDate.setText(mNote.getmNoteTime() + "");


        tvFeelOnday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(mcontext, "Hehe", Toast.LENGTH_SHORT).show();
                Intent intent;
                intent = new Intent(mcontext, MusicActivity.class);
                mcontext.startActivity(intent);

            }
        });
        tvFeelOnday.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                tvFeelOnday.setText("hehe");
                return true;
            }
        });
        return view;
    }

    @Override
    public CharSequence[] getAutofillOptions() {
        return new CharSequence[0];
    }
}
