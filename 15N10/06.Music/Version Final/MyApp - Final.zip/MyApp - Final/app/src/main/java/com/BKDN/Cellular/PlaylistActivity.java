package com.BKDN.Cellular;

import android.Manifest;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.BKDN.Cellular.adapterRecycleView.PagerAdapter;
import com.BKDN.Cellular.object.Album;
import com.BKDN.Cellular.object.MyDatabase;
import com.BKDN.Cellular.object.Note;
import com.BKDN.Cellular.object.Playlist;
import com.BKDN.Cellular.object.Song;
import com.BKDN.Cellular.secondary_activity.AddSongToList;
import com.BKDN.Cellular.secondary_activity.MusicActivity;
import com.BKDN.Cellular.secondary_activity.NoteNewActivity;
import com.BKDN.Cellular.secondary_activity.OptionActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import ir.mirrajabi.searchdialog.SimpleSearchDialogCompat;
import ir.mirrajabi.searchdialog.core.BaseSearchDialogCompat;
import ir.mirrajabi.searchdialog.core.SearchResultListener;

public class PlaylistActivity extends AppCompatActivity {
    public static ArrayList<Playlist> mListPlaylist;
    public static ArrayList<Song> mSongList;
    public static ArrayList<Note> mNoteList;
    public static ArrayList<Album> mAlbumList;

    private Button btnMenu;
    private FloatingActionButton floatingActionButton;
    private FloatingActionButton fbtnAdd, fbtnSetting, fbtnAddPlaylist;
    private boolean show = false;
    private TextView tvFbtnSetting, tvFbtnFeel, tvFbtnAddPlaylist;

    private TextView tvOption;

    private NavigationView navigationBar;
    private Button btnPlaylistMenu;

    public static ArrayList<Song> sSonglistCopy = new ArrayList<>();
    public static MyDatabase myDatabase;
    private ViewPager viewPager;

    String lang="";
    private Button btnSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_playlist);
        ReadStorage();
        getWidget();
        click();
        viewpager();
    }


    private void showNote() {
        Cursor dataNote = PlaylistActivity.myDatabase.GetData("SELECT * FROM Note");


        while (dataNote.moveToNext()) {
            int id = dataNote.getInt(0);
            String name = dataNote.getString(1);
            String detail = dataNote.getString(2);
            String date = dataNote.getString(3);
            String time = dataNote.getString(4);

            Note a = new Note(id, name, date, time, detail);
            mNoteList.add(0,a);
        }
    }

    private void showPlaylist() {

        ArrayList<Playlist> playlists = new ArrayList<>();
        Cursor dataPlaylist = PlaylistActivity.myDatabase.GetData("SELECT * FROM Playlist");
        ArrayList<Song> listSong = new ArrayList<>();
        String namePlaylistOld = "";
        boolean key = false;
        while (dataPlaylist.moveToNext()) {
            key = true;
            int id = dataPlaylist.getInt(0);
            String namePlaylist = dataPlaylist.getString(1);
            if (namePlaylistOld.compareTo("") == 0) namePlaylistOld = namePlaylist;
            int idSong = dataPlaylist.getInt(2);
            // Toast.makeText(this, ""+id+namePlaylist+idSong, Toast.LENGTH_SHORT).show();
            String songName = "";
            String songDuration = "";
            String songPath = "";
            int songCount = 0;
            if (namePlaylist.compareTo(namePlaylistOld) != 0) {
                ArrayList<Song> songs = new ArrayList<>();
                songs.addAll(listSong);
                playlists.add(new Playlist(namePlaylistOld, songs));
                listSong.clear();


            }
            Cursor dataSong = PlaylistActivity.myDatabase.GetData("SELECT * FROM Song");
            while (dataSong.moveToNext()) {
                int idCursor = dataSong.getInt(0);
                if (idCursor == idSong) {
                    songName = dataSong.getString(1);
                    songDuration = dataSong.getString(2);
                    songPath = dataSong.getString(3);
                    songCount = dataSong.getInt(4);
                    Song song = new Song(songName, songDuration, songPath, songCount);
                    listSong.add(song);
                    break;
                }

            }
            namePlaylistOld = namePlaylist;
        }
        if (key == true) {
            ArrayList<Song> songs = new ArrayList<>();
            songs.addAll(listSong);
            playlists.add(new Playlist(namePlaylistOld, songs));
            listSong.clear();
            mListPlaylist.addAll(playlists);
        }
    }
    public void viewpager() {
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        //tabLayout.addTab(tabLayout.newTab().setText("Ghi chú"));
        tabLayout.addTab(tabLayout.newTab().setText(getResources().getString(R.string.tab_ghi_chu)));
        tabLayout.addTab(tabLayout.newTab().setText(getResources().getString(R.string.tab_nhac)));
        tabLayout.addTab(tabLayout.newTab().setText("Playlist"));
        //tabLayout.addTab(tabLayout.newTab().setText("Album"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        viewPager = (ViewPager) findViewById(R.id.pager);
        final PagerAdapter adapter = new PagerAdapter
                (getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }


            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });


    }

    public void getWidget() {
        btnMenu = (Button) findViewById(R.id.btn_playlist_menu);

        floatingActionButton = (FloatingActionButton) findViewById(R.id.fab);
        fbtnAdd = (FloatingActionButton) findViewById(R.id.fbtn_add_note);
        fbtnSetting = (FloatingActionButton) findViewById(R.id.fbtn_setting);
        fbtnAddPlaylist = (FloatingActionButton) findViewById(R.id.fbtn_add_playlist);

        tvFbtnSetting = (TextView) findViewById(R.id.tv_fbtn_setting);
        tvFbtnFeel = (TextView) findViewById(R.id.tv_fbtn_feel);
        tvFbtnAddPlaylist = (TextView) findViewById(R.id.tv_fbtn_add_playlist);
        myDatabase = new MyDatabase(this, "data.sql", null, 1);
        init();
        tvOption = (TextView) findViewById(R.id.tv_option);
        navigationBar = (NavigationView) findViewById(R.id.navigation_bar);
        btnPlaylistMenu = (Button) findViewById(R.id.btn_playlist_menu);

        btnSearch= (Button) findViewById(R.id.btnSearch);
    }

    public void init() {
        mListPlaylist = new ArrayList<>();
        mSongList = new ArrayList<>();
        mNoteList = new ArrayList<>();
        mAlbumList = new ArrayList<>();
        mAlbumList.add(new Album("Nhac cach mang", 13));
        mAlbumList.add(new Album("Nhac tre", 8));
        mAlbumList.add(new Album("Nhac remix", 11));
        mAlbumList.add(new Album("Nhac tru tinh", 16));
        mAlbumList.add(new Album("Nhac bolero", 3));
        mAlbumList.add(new Album("Nhac cach mang", 13));
        myDatabase.QueryData("CREATE TABLE IF NOT EXISTS Note(Id INTEGER PRIMARY KEY AUTOINCREMENT, Name VARCHAR(160), Detail VARCHAR(2000), Date VARCHAR(20),Time VARCHAR(20))");
        myDatabase.QueryData("CREATE TABLE IF NOT EXISTS Song(Id INTEGER PRIMARY KEY AUTOINCREMENT, Name VARCHAR(160), Duration VARCHAR(20), Path VARCHAR(2000),Count INTEGER)");

        // myDatabase.QueryData("CREATE TABLE IF NOT EXISTS Playlist(Id INTEGER PRIMARY KEY AUTOINCREMENT, PlaylistName VARCHAR(100), SongName VARCHAR(200), SongPath VARCHAR(200),SongDuration VARCHAR(20))");
        myDatabase.QueryData("CREATE TABLE IF NOT EXISTS Playlist(Id INTEGER PRIMARY KEY AUTOINCREMENT, PlaylistName VARCHAR(100), IdSong INTEGER)");
        SharedPreferences sharePreferences = getPreferences(MODE_PRIVATE);
        boolean load = sharePreferences.getBoolean("key_check", true);
        /////////////////////////
       /* String language=sharePreferences.getString("LANGUAGE","vi");
        if(language.compareTo("vi")==0){

        }else {

        }*/
        /////////////////////////////////

        if (load) {
            SharedPreferences.Editor editor = sharePreferences.edit();
            editor.putBoolean("key_check", false);
            ////////////////////////////////////


            ///////////////////////////
            editor.commit();
            //startActivity(new Intent(P));
            getSongList();
        } else {

            Cursor dataSong = PlaylistActivity.myDatabase.GetData("SELECT * FROM Song");
            while (dataSong.moveToNext()) {
                int id = dataSong.getInt(0);
                String name = dataSong.getString(1);
                String duration = dataSong.getString(2);
                String path = dataSong.getString(3);
                int count = dataSong.getInt(4);
                Song a = new Song(id, name, duration, path, count);
                mSongList.add(a);
            }
            copySongList();
        }
        showNote();
        showPlaylist();

        Collections.sort(mSongList, new Comparator<Song>() {
            public int compare(Song a, Song b) {
                if (a.getCount() > b.getCount()) return -1;
                else if (a.getCount() == b.getCount()) return 0;
                return 1;
            }
        });

    }

    public void click() {

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (show == false) {
                    fbtnAdd.show();
                    fbtnSetting.show();
                    fbtnAddPlaylist.show();

                    tvFbtnFeel.setVisibility(View.VISIBLE);
                    tvFbtnSetting.setVisibility(View.VISIBLE);
                    tvFbtnAddPlaylist.setVisibility(View.VISIBLE);

                    viewPager.setVisibility(View.INVISIBLE);
                    show = true;
                } else {
                    fbtnAdd.hide();
                    fbtnSetting.hide();
                    fbtnAddPlaylist.hide();

                    tvFbtnFeel.setVisibility(View.INVISIBLE);
                    tvFbtnSetting.setVisibility(View.INVISIBLE);
                    tvFbtnAddPlaylist.setVisibility(View.INVISIBLE);

                    viewPager.setVisibility(View.VISIBLE);
                    show = false;
                }

            }
        });


        tvOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PlaylistActivity.this, OptionActivity.class));
            }
        });
        fbtnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PlaylistActivity.this, NoteNewActivity.class));
            }
        });
        fbtnSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PlaylistActivity.this, OptionActivity.class));
            }
        });

        fbtnAddPlaylist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PlaylistActivity.this, AddSongToList.class));
            }
        });

        btnPlaylistMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(PlaylistActivity.this, "Clicked", Toast.LENGTH_SHORT).show();
            }
        });

        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openMainActivity = new Intent(PlaylistActivity.this, MusicActivity.class);
                openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivityIfNeeded(openMainActivity, 0);
            }
        });


        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openMainActivity = new Intent(PlaylistActivity.this, MusicActivity.class);
                openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivityIfNeeded(openMainActivity, 0);
            }
        });

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {
                new SimpleSearchDialogCompat<>(PlaylistActivity.this,getResources().getString(R.string.search), getResources().getString(R.string.search_what), null, InitData(), new SearchResultListener<Song>() {
                    @Override
                    public void onSelected(BaseSearchDialogCompat baseSearchDialogCompat, Song song, int i) {
                        Toast.makeText(PlaylistActivity.this, "Hello"+song.getmPathSong(), Toast.LENGTH_SHORT).show();


                        if (MusicActivity.mediaPlayer.isPlaying()){
                            MusicActivity.mediaPlayer.stop();
                            MusicActivity.mediaPlayer.release();
                        }
                        int position=i;
                        Intent intent = new Intent(view.getContext(), MusicActivity.class);
                        intent.putExtra("START_SONG_POSITION", position);
                        intent.putExtra("RECEIVE_INTENT_SONG",1122);
                        // intent.putExtra("SongList", (Serializable) mSongList);
                        view.getContext().startActivity(intent);




                        baseSearchDialogCompat.dismiss();
                    }
                }).show();
            }
        });
    }

    private ArrayList<Song> InitData() {
        ArrayList<Song> listSearch=new ArrayList<>();
        listSearch.addAll(PlaylistActivity.mSongList);
        return listSearch;
    }

    public void getSongList() {
        ContentResolver musicResolver = getContentResolver();
        Uri musicUri = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor musicCursor = musicResolver.query(musicUri, null, null, null, null);


        if (musicCursor != null && musicCursor.moveToFirst()) {
            //get columns
            //String path=musicUri.getPath(); sai cmnr
            int titleColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.TITLE);
            int idColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media._ID);
            int artistColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.ARTIST);
            int durationColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.DURATION);

            int imageColumn = musicCursor.getColumnIndex
                    (android.provider.MediaStore.Audio.AlbumColumns.ALBUM_ART);
            int pathColumn = musicCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
            do {
                long thisId = musicCursor.getLong(idColumn);
                String thisTitle = musicCursor.getString(titleColumn);
                String thisArtist = musicCursor.getString(artistColumn);
                String thisPath = musicCursor.getString(pathColumn);
                long thisDuration = musicCursor.getLong(durationColumn);
                SimpleDateFormat dinhdanggio= new SimpleDateFormat("mm:ss");
                String thisDurationString=dinhdanggio.format(thisDuration);
                if (!thisPath.endsWith(".ogg")) {
                    myDatabase.QueryData("INSERT INTO Song VALUES(null,'" + thisTitle + "','" + thisDurationString + "', '" + thisPath + "' ,0)");
                }
            }
            while (musicCursor.moveToNext());
        }

        ContentResolver musicResolverInternal = getContentResolver();
        Uri musicUriInternal = MediaStore.Audio.Media.INTERNAL_CONTENT_URI;
        Cursor musicCursorInternal = musicResolverInternal.query(musicUriInternal, null, null, null, null);
        if (musicCursorInternal != null && musicCursorInternal.moveToFirst()) {
            //get columns
            //String path=musicUri.getPath(); sai cmnr
            int titleColumn = musicCursorInternal.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.TITLE);
            int idColumn = musicCursorInternal.getColumnIndex
                    (android.provider.MediaStore.Audio.Media._ID);
            int artistColumn = musicCursorInternal.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.ARTIST);
            int durationColumn = musicCursorInternal.getColumnIndex
                    (android.provider.MediaStore.Audio.Media.DURATION);

            int imageColumn = musicCursorInternal.getColumnIndex
                    (android.provider.MediaStore.Audio.AlbumColumns.ALBUM_ART);
            int pathColumn = musicCursorInternal.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
            do {
                long thisId = musicCursorInternal.getLong(idColumn);
                String thisTitle = musicCursorInternal.getString(titleColumn);
                String thisArtist = musicCursorInternal.getString(artistColumn);
                String thisPath = musicCursorInternal.getString(pathColumn);
                long thisDuration = musicCursorInternal.getLong(durationColumn);
                SimpleDateFormat dinhdanggio= new SimpleDateFormat("mm:ss");
                String thisDurationString=dinhdanggio.format(thisDuration);
                if (!thisPath.endsWith(".ogg")) {
                    myDatabase.QueryData("INSERT INTO Song VALUES(null,'" + thisTitle + "','" + thisDurationString + "', '" + thisPath + "' ,0)");
                }
            }
            while (musicCursor.moveToNext());
        }
















        /////////////moi lam 6/11/2017
        Cursor dataSong = PlaylistActivity.myDatabase.GetData("SELECT * FROM Song");
        while (dataSong.moveToNext()) {
            int id = dataSong.getInt(0);
            String name = dataSong.getString(1);
            String duration = dataSong.getString(2);
            String path = dataSong.getString(3);
            int count = dataSong.getInt(4);

            Song a = new Song(id, name, duration, path, count);
            mSongList.add(a);
        }
        copySongList();


    }


    public void copySongList() {
        for (int i = 0; i < mSongList.size(); i++) {
            sSonglistCopy.add(mSongList.get(i));
        }
    }

    public void item_option(View view) {

        switch (view.getId()) {
            case R.id.imgSongOption:

                //int position=view.posi
                // DialogSong();
                break;
            case R.id.imgPlaylistOption:
                // DialogPlaylist();
                break;
            case R.id.imgNoteOption:
                //DialogNote();
                break;
            case R.id.imgAlbumOption:
                //  DialogAlbum();
                break;

        }


    }

    private void DialogAlbum() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_item_album);
        dialog.show();
    }

    private void DialogNote() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_item_note);
        dialog.show();
    }

    private void DialogSong() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_item_song);

        TextView tvSetRingtone = dialog.findViewById(R.id.tvSetRingtone);
        tvSetRingtone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(PlaylistActivity.this, "Da set ringtone", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();

    }

    private void DialogPlaylist() {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_item_playlist);
        dialog.show();
    }

    private void ItemOption(View view) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.custom_item_song);
        dialog.show();

    }

    private void ReadStorage(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){

            String []permissions={
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE,
            };
            ActivityCompat.requestPermissions(this, permissions, 100);

        }
    }


    public void Search(final View view) {
        new SimpleSearchDialogCompat<>(PlaylistActivity.this,getResources().getString(R.string.search), getResources().getString(R.string.search_what), null, InitData(), new SearchResultListener<Song>() {
            @Override
            public void onSelected(BaseSearchDialogCompat baseSearchDialogCompat, Song song, int i) {
                Toast.makeText(PlaylistActivity.this, "Hello"+song.getmPathSong(), Toast.LENGTH_SHORT).show();


                if (MusicActivity.mediaPlayer.isPlaying()){
                    MusicActivity.mediaPlayer.stop();
                    MusicActivity.mediaPlayer.release();
                }
                int position=i;
                Intent intent = new Intent(view.getContext(), MusicActivity.class);
                intent.putExtra("START_SONG_POSITION", position);
                intent.putExtra("RECEIVE_INTENT_SONG",1122);
                // intent.putExtra("SongList", (Serializable) mSongList);
                view.getContext().startActivity(intent);




                baseSearchDialogCompat.dismiss();
            }
        }).show();
    }

    public void Reload(View view) {
        myDatabase.QueryData("DELETE FROM Song");
        Toast.makeText(this, "OK", Toast.LENGTH_SHORT).show();
        getSongList();
        startActivity(new Intent(this,PlaylistActivity.class));
    }

    public void Help(View view) {
        Toast.makeText(this,getResources().getString(R.string.help_app), Toast.LENGTH_SHORT).show();
    }

    public void AboutApp(View view) {
    }
}
