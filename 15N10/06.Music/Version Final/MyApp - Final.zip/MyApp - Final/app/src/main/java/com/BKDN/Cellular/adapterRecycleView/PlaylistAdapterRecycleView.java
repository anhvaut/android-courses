package com.BKDN.Cellular.adapterRecycleView;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.BKDN.Cellular.PlaylistActivity;
import com.BKDN.Cellular.R;
import com.BKDN.Cellular.object.Playlist;
import com.BKDN.Cellular.secondary_activity.ShowPlaylist;

import java.util.ArrayList;

/**
 * Created by Administrator on 10/27/2017.
 */

public class PlaylistAdapterRecycleView extends RecyclerView.Adapter<PlaylistAdapterRecycleView.Viewholder> {

    private ArrayList<Playlist> playlistArraylist;
    private Context context;

    public PlaylistAdapterRecycleView(ArrayList<Playlist> playlistArraylist, Context context) {
        this.playlistArraylist = playlistArraylist;
        this.context = context;
    }

    @Override
    public Viewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View itemView = layoutInflater.inflate(R.layout.item_activity_list_playlist, parent, false);
        return new Viewholder(itemView);
    }

    @Override
    public void onBindViewHolder(Viewholder holder, int position) {
        holder.tvPlaylistName.setText(playlistArraylist.get(position).getmPlaylistName());

       // holder.tvPlaylistSize.setText(playlistArraylist.get(position).getmPlaylistSize()+"");
        holder.tvPlaylistSize.setText(playlistArraylist.get(position).getPlaylistListSong().size()+" "+holder.itemView.getResources().getString(R.string.bai_hat));

    }

    @Override
    public int getItemCount() {
        return playlistArraylist.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        TextView tvPlaylistName;
        TextView tvPlaylistSize;
        ImageView imgPlaylistOption;

        public Viewholder(final View itemView) {
            super(itemView);
            tvPlaylistName = (TextView) itemView.findViewById(R.id.tv_playlist_name);
            tvPlaylistSize = (TextView) itemView.findViewById(R.id.tv_num_of_songs);
            imgPlaylistOption= (ImageView) itemView.findViewById(R.id.imgPlaylistOption);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                   /* Intent intent = new Intent(itemView.getContext(), AddSongToList.class);
                    //startActivity(intent);//error
                    itemView.getContext().startActivity(intent);
                    //itemView.getContext().startActivity();
                    */

                   Intent intent=new Intent(itemView.getContext(), ShowPlaylist.class);
                    intent.putExtra("ShowPlaylist",getAdapterPosition());
                    itemView.getContext().startActivity(intent);

                }
            });

            imgPlaylistOption.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Dialog dialog = new Dialog(view.getContext());


                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    dialog.setContentView(R.layout.custom_item_playlist);
                    TextView tvDetail= (TextView) dialog.findViewById(R.id.tvPlaylistDetail);
                    String detail="*Name: "+PlaylistActivity.mListPlaylist.get(getAdapterPosition()).getmPlaylistName()
                            +"\n*Number: "+PlaylistActivity.mListPlaylist.get(getAdapterPosition()).getmPlaylistSize()+" songs";
                    tvDetail.setText(detail);

                    dialog.show();

                    TextView tvDelete= (TextView) dialog.findViewById(R.id.tvPlaylistDelete);
                    TextView tvRename= (TextView) dialog.findViewById(R.id.tvPlaylistRename);
                    tvDelete.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            PlaylistActivity.myDatabase.QueryData("DELETE FROM Playlist WHERE PlaylistName='"+PlaylistActivity.mListPlaylist.get(getAdapterPosition()).getmPlaylistName()+"' ");
                            Toast.makeText(view.getContext(), "Da xoa", Toast.LENGTH_SHORT).show();
                            view.getContext().startActivity(new Intent(view.getContext(),PlaylistActivity.class));
                        }
                    });
                    tvRename.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Dialog dialog = new Dialog(view.getContext());
                            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                            dialog.setContentView(R.layout.custom_item_playlist_rename);

                            final EditText edtNamePlaylist= (EditText) dialog.findViewById(R.id.edtPlaylistName);
                            Button btnRename= (Button) dialog.findViewById(R.id.btnPlaylistRename);
                            edtNamePlaylist.setText(PlaylistActivity.mListPlaylist.get(getAdapterPosition()).getmPlaylistName());
                            final String oldName=PlaylistActivity.mListPlaylist.get(getAdapterPosition()).getmPlaylistName().toString();
                            dialog.show();
                            btnRename.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    String name=edtNamePlaylist.getText().toString();
                                    PlaylistActivity.myDatabase.QueryData("UPDATE Playlist SET PlaylistName='"+name+"' WHERE PlaylistName='"+oldName+"' ");
                                    Toast.makeText(view.getContext(), "OK", Toast.LENGTH_SHORT).show();
                                    view.getContext().startActivity(new Intent(view.getContext(),PlaylistActivity.class));
                                }
                            });

                        }
                    });
                }
            });
        }
    }


}



















