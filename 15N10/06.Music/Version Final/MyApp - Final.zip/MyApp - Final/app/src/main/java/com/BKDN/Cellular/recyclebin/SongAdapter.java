package com.BKDN.Cellular.recyclebin;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.BKDN.Cellular.secondary_activity.MusicActivity;
import com.BKDN.Cellular.R;
import com.BKDN.Cellular.object.Song;

import java.io.Serializable;
import java.util.List;

/**
 * Created by Administrator on 9/9/2017.
 */

public class SongAdapter extends BaseAdapter {
    private Context mcontext;
    private int layout;
    private List<Song> mSongList;

    public SongAdapter(Context mcontext, int layout, List<Song> mSongList) {
        this.mcontext = mcontext;
        this.layout = layout;
        this.mSongList = mSongList;
    }

    @Override
    public int getCount() {
        return mSongList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    private class ViewHolder {
        TextView tvNameSong;
        TextView tvTimeSong;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if (view == null) {
            final LayoutInflater inflater = (LayoutInflater) mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(layout, null);
            viewHolder = new ViewHolder();
            viewHolder.tvNameSong = (TextView) view.findViewById(R.id.tv_song_name);
            viewHolder.tvTimeSong = (TextView) view.findViewById(R.id.tv_time_song);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }


        final Song mSong = mSongList.get(i);

        viewHolder.tvNameSong.setText(mSong.getmNameSong().toString());
        viewHolder.tvTimeSong.setText(mSong.getmTimeSong() + "");

        final int j = i;

        // lam them
        viewHolder.tvNameSong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*MediaPlayer mediaPlayer= new  MediaPlayer();
                try {
                    mediaPlayer.setDataSource(mSong.getmPathSong());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    mediaPlayer.prepare();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                mediaPlayer.start();*/
                Intent intent = new Intent(mcontext, MusicActivity.class);
                intent.putExtra("0000", j);
                intent.putExtra("SongList", (Serializable) mSongList);
                mcontext.startActivity(intent);
            }
        });
        return view;
    }

    @Override
    public CharSequence[] getAutofillOptions() {
        return new CharSequence[0];
    }
}
