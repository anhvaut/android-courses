package com.BKDN.Cellular.recyclebin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.BKDN.Cellular.object.Album;
import com.BKDN.Cellular.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 9/8/2017.
 */

public class AlbumAdapter extends BaseAdapter {
    private Context mcontext;
    private int layout;
    private List<Album> albums;

    public AlbumAdapter(Context mcontext, int layout, ArrayList<Album> albums) {
        this.mcontext = mcontext;
        this.layout = layout;
        this.albums = albums;
    }

    @Override
    public int getCount() {
        return albums.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater = (LayoutInflater) mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(layout, null);
        TextView tvNameAlbum = (TextView) view.findViewById(R.id.tv_album_name);
        TextView tvNumOfSOngsOnAlbum = (TextView) view.findViewById(R.id.tv_num_of_song_on_album);

        Album mAlbum = albums.get(i);

        tvNameAlbum.setText(mAlbum.getmAlbumName().toString());
        tvNumOfSOngsOnAlbum.setText(mAlbum.getmAlbumSize() + " bài hát.");
        return view;
    }

    @Override
    public CharSequence[] getAutofillOptions() {
        return new CharSequence[0];
    }
}
