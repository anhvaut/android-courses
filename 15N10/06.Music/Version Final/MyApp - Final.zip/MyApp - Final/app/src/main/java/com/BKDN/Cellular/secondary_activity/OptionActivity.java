package com.BKDN.Cellular.secondary_activity;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.BKDN.Cellular.PlaylistActivity;
import com.BKDN.Cellular.R;

import java.util.Locale;

public class OptionActivity extends AppCompatActivity {

    private String lang;
    private LinearLayout lnloLanguage;
    private TextView tvShuffle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_option);
        GetWidget();
        Click();
    }

    private void Click() {
        SharedPreferences sharePreferences = getPreferences(MODE_PRIVATE);
        final SharedPreferences.Editor editor=sharePreferences.edit();
        lnloLanguage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(view.getContext());
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.select_language);

                ImageView imgVi= (ImageView) dialog.findViewById(R.id.imgVietnamese);
                ImageView imgEn= (ImageView) dialog.findViewById(R.id.imgEnglish);
                dialog.show();
                imgVi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        lang="vi";
                        editor.putString("LANGUAGE",lang);
                        editor.commit();
                        SetLanguage(lang);
                        view.getContext().startActivity(new Intent(view.getContext(),PlaylistActivity.class));
                    }
                });
                imgEn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        lang="en";
                        editor.putString("LANGUAGE",lang);
                        editor.commit();
                        SetLanguage(lang);
                        view.getContext().startActivity(new Intent(view.getContext(),PlaylistActivity.class));
                    }
                });
            }
        });
    }

    private void GetWidget() {

        lnloLanguage= (LinearLayout) findViewById(R.id.lnloLanguage);
        tvShuffle= (TextView) findViewById(R.id.tvShuffle);
    }
    public void SetLanguage(String language){
        Locale myLocale = new Locale(language);
        Locale.setDefault(myLocale);
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale=myLocale;
        res.updateConfiguration(conf, dm);
    }

    public void Shuffle(View view) {

        MusicActivity.isSuffle=!MusicActivity.isSuffle;
        try {
            if (MusicActivity.isSuffle) {
                Toast.makeText(this, getResources().getString(R.string.music_ngau_nhien), Toast.LENGTH_SHORT).show();
                MusicActivity.btnSuffle.setBackgroundResource(R.drawable.ic_random);
                tvShuffle.setText(getResources().getString(R.string.txt_co));
            } else {
                Toast.makeText(this, getResources().getString(R.string.music_ngau_nhien_off), Toast.LENGTH_SHORT).show();
                MusicActivity.btnSuffle.setBackgroundResource(R.drawable.ic_shuffle);
                tvShuffle.setText(getResources().getString(R.string.txt_khong));
            }
        }
        catch (NullPointerException e){

        }
    }
}
