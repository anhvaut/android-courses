package com.BKDN.Cellular.recyclebin;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.widget.Toast;

import com.BKDN.Cellular.object.Song;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 9/25/2017.
 */

public class MusicService extends Service {
    private MediaPlayer mediaPlayer;//=new MediaPlayer();
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public MusicService() {
        super();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Toast.makeText(this, "Khởi tạo nhạc", Toast.LENGTH_SHORT).show();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        List<Song> songListGet= new ArrayList<>();
        songListGet=(List<Song>) intent.getSerializableExtra("SongList");
        int position=intent.getIntExtra("1111",1);
        if (position!=-1){
            Song mSong = songListGet.get(position);
            mediaPlayer = new MediaPlayer();
            try {
                mediaPlayer.setDataSource(mSong.getmPathSong());
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                mediaPlayer.prepare();
            } catch (IOException e) {
                e.printStackTrace();
            }
            mediaPlayer.setLooping(true);
            mediaPlayer.start();
        }

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
        mediaPlayer.release();

    }
}
