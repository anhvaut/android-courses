package com.BKDN.Cellular.fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.BKDN.Cellular.PlaylistActivity;
import com.BKDN.Cellular.R;
import com.BKDN.Cellular.adapterRecycleView.SongAdapterRecycleView;
import com.BKDN.Cellular.object.Song;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * Created by Administrator on 10/27/2017.
 */

public class SongFragment extends Fragment {

    private RecyclerView recyclerView;

    private ArrayList<Song> arraylist;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.fragment_song, container, false);

        recyclerView= (RecyclerView) view.findViewById(R.id.recycleViewSong);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this.getContext(),LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(linearLayoutManager);
        // lam duong bien
        DividerItemDecoration dividerItemDecoration=new DividerItemDecoration(this.getContext(),linearLayoutManager.getOrientation());
        recyclerView.addItemDecoration(dividerItemDecoration);
        arraylist=new ArrayList<>();

        arraylist.addAll(PlaylistActivity.mSongList);

        Collections.sort(arraylist, new Comparator<Song>() {
            public int compare(Song a, Song b) {
                if (a.getCount()>b.getCount()) return -1;
                else if (a.getCount()==b.getCount()) return 0;
                return 1;
            }
        });
        SongAdapterRecycleView songAdapterRecycle=new SongAdapterRecycleView(arraylist,getContext());

        recyclerView.setAdapter(songAdapterRecycle);





        // Inflate the layout for this fragment
//        img =(ImageView) view.findViewById(R.id.img_logo);
//        img.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(getContext(), "da click", Toast.LENGTH_SHORT).show();
//            }
//        });
        return view;
    }
}
