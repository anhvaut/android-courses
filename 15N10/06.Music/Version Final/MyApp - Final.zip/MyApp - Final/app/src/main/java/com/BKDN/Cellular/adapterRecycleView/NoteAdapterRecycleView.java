package com.BKDN.Cellular.adapterRecycleView;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.BKDN.Cellular.PlaylistActivity;
import com.BKDN.Cellular.R;
import com.BKDN.Cellular.object.Note;
import com.BKDN.Cellular.secondary_activity.NoteUpdateActivity;

import java.util.ArrayList;

/**
 * Created by Administrator on 10/27/2017.
 */

public class NoteAdapterRecycleView  extends RecyclerView.Adapter<NoteAdapterRecycleView.Viewholder>{

    ArrayList<Note> noteArrayList;
    Context context;

    public NoteAdapterRecycleView(ArrayList<Note> noteArrayList, Context context) {
        this.noteArrayList = noteArrayList;
        this.context = context;
    }

    @Override
    public Viewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View itemView=layoutInflater.inflate(R.layout.item_activity_list_note,parent,false);
        return new Viewholder(itemView);
    }

    @Override
    public void onBindViewHolder(Viewholder holder, int position) {
        holder.tvNoteName.setText(noteArrayList.get(position).getmNoteName());
        holder.tvNoteDate.setText(noteArrayList.get(position).getmNoteTime()+"  "+noteArrayList.get(position).getmNoteDate());
        holder.tvNoteDetail.setText(noteArrayList.get(position).getmDetail());

    }

    @Override
    public int getItemCount() {
        return noteArrayList.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        TextView tvNoteName;
        TextView tvNoteDate;
        ImageView imgNoteOption;
        TextView tvNoteDetail;

        public Viewholder(final View itemView) {
            super(itemView);
            tvNoteName= (TextView) itemView.findViewById(R.id.tv_note_name);
            tvNoteDate= (TextView) itemView.findViewById(R.id.tv_note_date);
            imgNoteOption= (ImageView) itemView.findViewById(R.id.imgNoteOption);
            tvNoteDetail=(TextView) itemView.findViewById(R.id.tv_note_detail);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    toast(getAdapterPosition());
                }
            });

            tvNoteDate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(itemView.getContext(), "Dax chon", Toast.LENGTH_SHORT).show();
                }
            });
            
            imgNoteOption.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(view.getContext()   , "da clicked option", Toast.LENGTH_SHORT).show();
                    Dialog dialog = new Dialog(view.getContext());
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    dialog.setContentView(R.layout.custom_item_note);

                    TextView tvNoteDetail=(TextView)  dialog.findViewById(R.id.tvNoteDetail);
                    TextView tvNoteEdit= (TextView) dialog.findViewById(R.id.tvNoteEdit);
                    String detail="*Name: "+PlaylistActivity.mNoteList.get(getAdapterPosition()).getmNoteName()
                            +"\n*Time: "+PlaylistActivity.mNoteList.get(getAdapterPosition()).getmNoteTime()
                            +"\n*Date: "+PlaylistActivity.mNoteList.get(getAdapterPosition()).getmNoteDate()
                            +"\n*Content: "+PlaylistActivity.mNoteList.get(getAdapterPosition()).getmDetail();
                    tvNoteDetail.setText(detail);
                    
                    TextView tvDelete=(TextView) dialog.findViewById(R.id.tvNoteDelete);
                    dialog.show();
                    tvDelete.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            PlaylistActivity.myDatabase.QueryData("DELETE FROM Note WHERE Id='"+PlaylistActivity.mNoteList.get(getAdapterPosition()).getmId()+"' ");
                            Toast.makeText(view.getContext(), "Da xoa", Toast.LENGTH_SHORT).show();
                            view.getContext().startActivity(new Intent(view.getContext(),PlaylistActivity.class));
                        }
                    });
                    tvNoteEdit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent intent=new Intent(view.getContext(), NoteUpdateActivity.class);
                            intent.putExtra("NOTE_POSITION",getAdapterPosition());
                            view.getContext().startActivity(intent);
                        }
                    });


                }
            });

        }
    }
    public void toast(int position){
        String toast="";
        toast=noteArrayList.get(position).getmNoteName()+"\n"+noteArrayList.get(position).getmDetail()
                +"\n"+noteArrayList.get(position).getmNoteTime()+" "+noteArrayList.get(position).getmNoteDate();
        Toast.makeText(context,toast, Toast.LENGTH_SHORT).show();

    }
}



















