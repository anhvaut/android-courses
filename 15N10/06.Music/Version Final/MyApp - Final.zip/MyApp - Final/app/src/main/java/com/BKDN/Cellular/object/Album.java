package com.BKDN.Cellular.object;

import android.graphics.Bitmap;

public class Album {
    private String mAlbumName;
    private Bitmap mIconAlbum;
    private int mAlbumSize;

    public Album(String mAlbumName, int mNumOfSongs) {
        this.mAlbumName = mAlbumName;
        this.mAlbumSize = mNumOfSongs;
    }

    public String getmAlbumName() {
        return mAlbumName;
    }

    public void setmAlbumName(String mAlbumName) {
        this.mAlbumName = mAlbumName;
    }

    public Bitmap getmIconAlbum() {
        return mIconAlbum;
    }

    public void setmIconAlbum(Bitmap mIconAlbum) {
        this.mIconAlbum = mIconAlbum;
    }

    public int getmAlbumSize() {
        return mAlbumSize;
    }

    public void setmAlbumSize(int mAlbumSize) {
        this.mAlbumSize = mAlbumSize;
    }
}
