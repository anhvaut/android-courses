package com.BKDN.Cellular.secondary_activity;

import android.app.Notification;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.BKDN.Cellular.PlaylistActivity;
import com.BKDN.Cellular.R;
import com.BKDN.Cellular.object.Song;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Random;

/**
 * Created by Administrator on 9/25/2017.
 */

public class MusicActivity extends AppCompatActivity {
    private ImageView imgDia;
    private Button btnPlayPause;
    private TextView tvSongName;
    public static MediaPlayer mediaPlayer=new MediaPlayer();

    int position;
    private Button btnNext,btnPre;

    private SeekBar sb_play;
    private TextView tv_start,tv_end;

    Animation animation;

    public static boolean isSuffle=false;
    private int repeat=0;
    public static Button btnSuffle,btnRepeat;

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);

        AnhXa();
        ReceiveIntent();
        Click();


    }

    private void ReceiveIntent() {
        Intent intent = getIntent();
        position = intent.getIntExtra("START_SONG_POSITION", -1);
        int mess=intent.getIntExtra("RECEIVE_INTENT_SONG",0);
        int positionPlaylist=intent.getIntExtra("START_PLAYLIST_POSITION",-2);
        if (position != -1 && mess==1122 && positionPlaylist==-2) {
            mess=0;
            PlaylistActivity.sSonglistCopy.clear();
            PlaylistActivity.sSonglistCopy=new ArrayList<>();
            try {
                PlaylistActivity.sSonglistCopy.addAll(PlaylistActivity.mSongList);
            }catch (NullPointerException e){

            }
            prepareMusicList(PlaylistActivity.sSonglistCopy);
        }
        if (position != -1 && positionPlaylist!=-2) {
            mess=0;
            PlaylistActivity.sSonglistCopy.clear();
            PlaylistActivity.sSonglistCopy.addAll(PlaylistActivity.mListPlaylist.get(positionPlaylist).getPlaylistListSong());
            prepareMusicList(PlaylistActivity.sSonglistCopy);
        }

    }

    @Override
    protected void onStart() {
        super.onStart();

    }

    private void AnhXa() {
        imgDia = (ImageView) findViewById(R.id.img_disk);
        btnPlayPause = (Button) findViewById(R.id.btn_play);
        tvSongName = (TextView) findViewById(R.id.tv_name_song);
        mediaPlayer = new MediaPlayer();


        sb_play=(SeekBar) findViewById(R.id.sb_play);
        tv_start=(TextView) findViewById(R.id.tv_start);
        tv_end=(TextView) findViewById(R.id.tv_end);


        //21/10
        btnNext= (Button) findViewById(R.id.btn_next);
        btnPre= (Button) findViewById(R.id.btn_pre);

        btnSuffle= (Button) findViewById(R.id.btnSuffle);
        btnRepeat= (Button) findViewById(R.id.btnRepeat);
    }

    private void Click() {
        sb_play.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                SimpleDateFormat dinhdanggio= new SimpleDateFormat("mm:ss");
                tv_start.setText(dinhdanggio.format(i));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mediaPlayer.seekTo(sb_play.getProgress());

            }
        });
        SetTimeTotal();
        UpdateTimeSong();
        btnPlayPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String note="";
                if (PlaylistActivity.mNoteList.isEmpty()) note="***";
                else note=PlaylistActivity.mNoteList.get(0).getmNoteName();
                NotificationCompat.Builder notification= new NotificationCompat.Builder(MusicActivity.this)
                        .setSmallIcon(R.drawable.ic_back)
                        .setLargeIcon(BitmapFactory.decodeResource(getResources(),R.mipmap.ic_launcher))
                        .setContentTitle(getResources().getString(R.string.notify_dang_phat)+PlaylistActivity.mSongList.get(position).getmNameSong())
                        .setContentText(getResources().getString(R.string.notify_ghi_chu)+note);
                notification.setDefaults(Notification.DEFAULT_SOUND|Notification.DEFAULT_LIGHTS| Notification.DEFAULT_VIBRATE);
                NotificationManagerCompat notificationManagerCompat=NotificationManagerCompat.from(MusicActivity.this);
               notificationManagerCompat.notify(10,notification.build());

/////////////////////////////
                if (mediaPlayer.isPlaying()){
                    btnPlayPause.setBackgroundResource(R.drawable.ic_play);
                    NoRotate();
                    mediaPlayer.pause();
                }
                else {
                    Rotate();

                    btnPlayPause.setBackgroundResource(R.drawable.ic_pause);
                    mediaPlayer.start();
                }
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.stop();
                mediaPlayer.release();

                if(isSuffle){

                    Random random=new Random();
                    position=random.nextInt(PlaylistActivity.sSonglistCopy.size()-1);
                }
                else position++;
                if (position>PlaylistActivity.sSonglistCopy.size()-1) position=0;


                MediaPlayer mediaPlayer2=new MediaPlayer();
                try {
                    mediaPlayer2.setDataSource(PlaylistActivity.sSonglistCopy.get(position).getmPathSong());
                    mediaPlayer2.prepare();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                btnPlayPause.setBackgroundResource(R.drawable.ic_pause);
                mediaPlayer=mediaPlayer2;
                mediaPlayer.start();
                String name=PlaylistActivity.sSonglistCopy.get(position).getmNameSong().toString();
                if (name.length()>30) name=name.substring(0,30).concat("...");

                tvSongName.setText(name);
                SetTimeTotal();
                UpdateTimeSong();
                Rotate();

            }
        });
        btnPre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.stop();
                mediaPlayer.release();

                if(isSuffle){

                    Random random=new Random();
                    position=random.nextInt(PlaylistActivity.sSonglistCopy.size()-1);
                }
                else position--;

                if (position<0) position=PlaylistActivity.sSonglistCopy.size()-1;
                MediaPlayer mediaPlayer2=new MediaPlayer();
                try {
                    mediaPlayer2.setDataSource(PlaylistActivity.sSonglistCopy.get(position).getmPathSong());
                    mediaPlayer2.prepare();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                btnPlayPause.setBackgroundResource(R.drawable.ic_pause);
                mediaPlayer=mediaPlayer2;
                mediaPlayer.start();
                String name=PlaylistActivity.sSonglistCopy.get(position).getmNameSong().toString();
                if (name.length()>30) name=name.substring(0,30).concat("...");
                tvSongName.setText(name);
                SetTimeTotal();
                UpdateTimeSong();
                Rotate();
            }
        });


        btnSuffle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isSuffle==true){
                    isSuffle=false;
                    btnSuffle.setBackgroundResource(R.drawable.ic_shuffle);
                    Toast.makeText(MusicActivity.this,getResources().getString(R.string.music_ngau_nhien_off), Toast.LENGTH_SHORT).show();

                }
                else {
                    isSuffle=true;
                    btnSuffle.setBackgroundResource(R.drawable.ic_random);
                    Toast.makeText(MusicActivity.this,getResources().getString(R.string.music_ngau_nhien), Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnRepeat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (repeat==0){
                    repeat=1;
                    Toast.makeText(MusicActivity.this,getResources().getString(R.string.music_lap_1), Toast.LENGTH_SHORT).show();
                    btnRepeat.setBackgroundResource(R.drawable.ic_repeat_1);
                }
                else if (repeat==1){
                    repeat=2;
                    Toast.makeText(MusicActivity.this,getResources().getString(R.string.music_lap_all), Toast.LENGTH_SHORT).show();
                    btnRepeat.setBackgroundResource(R.drawable.ic_repeat_all);
                }
                else {
                    repeat=0;
                    Toast.makeText(MusicActivity.this,getResources().getString(R.string.music_lap_off), Toast.LENGTH_SHORT).show();
                    btnRepeat.setBackgroundResource(R.drawable.ic_repeat);
                }
            }
        });


    }



    public void doPausePlay(View view) {
        if(this.mediaPlayer.isPlaying())
        this.mediaPlayer.pause();
        else
            this.mediaPlayer.start();
    }
    void prepareMusicList(ArrayList<Song> list){

        Song mSong = list.get(position);
        tvSongName.setText(mSong.getmNameSong());
        try {
            mediaPlayer.setDataSource(mSong.getmPathSong());
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            mediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        mediaPlayer.setLooping(true);
        btnPlayPause.setBackgroundResource(R.drawable.ic_pause);
        mediaPlayer.start();
        Rotate();


    }


    private  void SetTimeTotal(){
        SimpleDateFormat dinhdanggio= new SimpleDateFormat("mm:ss");
        tv_end.setText(dinhdanggio.format(mediaPlayer.getDuration()));
        sb_play.setMax(mediaPlayer.getDuration());
    }
    private void UpdateTimeSong(){
        final Handler handler= new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                SimpleDateFormat dinhdanggio= new SimpleDateFormat("mm:ss");
                try {
                    tv_start.setText(dinhdanggio.format(mediaPlayer.getCurrentPosition()) + "");


                    //update progess sb_play
                    sb_play.setProgress(mediaPlayer.getCurrentPosition());
                    //kiem tra thoi gian bai hat->ket thuc -> next

                }catch (IllegalStateException e){
                    tv_start.setText("0:00");
                }


                mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer media) {
                        mediaPlayer.stop();
                        mediaPlayer.release();
                        if (repeat == 1){
                            Play();
                        }
                        else if ( repeat == 2 ){
                            position++;
                            if (position>PlaylistActivity.sSonglistCopy.size()-1) position=0;
                            Play();
                        }
                        else {
                            position++;
                            if (position == PlaylistActivity.sSonglistCopy.size()){

                            }
                            else {
                                Play();
                            }
                        }



                    }
                });
                handler.postDelayed(this,500);

            }
        },100);
    }


    public void Back(View view) {

        startActivity(new Intent(MusicActivity.this, PlaylistActivity.class));
    }
    public void Rotate(){
        animation= AnimationUtils.loadAnimation(MusicActivity.this,R.anim.rotate);
        imgDia.startAnimation(animation);
    }
    public void NoRotate(){
        animation= AnimationUtils.loadAnimation(MusicActivity.this,R.anim.no_rotate);
        imgDia.startAnimation(animation);
    }

    public void AddNote(View view) {
        startActivity(new Intent(MusicActivity.this, NoteNewActivity.class));
    }
    public void Play(){

        MediaPlayer mediaPlayer2=new MediaPlayer();
        try {
            mediaPlayer2.setDataSource(PlaylistActivity.sSonglistCopy.get(position).getmPathSong());
            mediaPlayer2.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        mediaPlayer=mediaPlayer2;
        mediaPlayer.start();
        String name=PlaylistActivity.sSonglistCopy.get(position).getmNameSong().toString();
        // if (name.length()>30) tvSongName.setTextSize(10);
        //else tvSongName.setTextSize(20);
        if (name.length()>30) name=name.substring(0,30).concat("...");

        tvSongName.setText(name);
        SetTimeTotal();
        UpdateTimeSong();
    }

}
