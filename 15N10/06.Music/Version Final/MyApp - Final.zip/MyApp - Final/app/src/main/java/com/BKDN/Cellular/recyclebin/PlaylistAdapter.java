package com.BKDN.Cellular.recyclebin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.BKDN.Cellular.object.Playlist;
import com.BKDN.Cellular.R;

import java.util.List;

/**
 * Created by Administrator on 9/8/2017.
 */

public class PlaylistAdapter extends BaseAdapter {
    private Context mcontext;
    private int layout;
    private List<Playlist> playlists;

    public PlaylistAdapter(Context mcontext, int layout, List<Playlist> playlists) {
        this.mcontext = mcontext;
        this.layout = layout;
        this.playlists = playlists;
    }

    @Override
    public int getCount() {
        return playlists.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater = (LayoutInflater) mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(layout, null);
        TextView tvNamePlaylist = (TextView) view.findViewById(R.id.tv_playlist_name);
        TextView tvNumOfSOngs = (TextView) view.findViewById(R.id.tv_num_of_songs);

        Playlist mPlaylist = playlists.get(i);

        tvNamePlaylist.setText(mPlaylist.getmPlaylistName().toString());
        tvNumOfSOngs.setText(mPlaylist.getmPlaylistSize() + " bài hát.");
        return view;
    }

    @Override
    public CharSequence[] getAutofillOptions() {
        return new CharSequence[0];
    }
}
