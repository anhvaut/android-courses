package com.BKDN.Cellular.secondary_activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.BKDN.Cellular.PlaylistActivity;
import com.BKDN.Cellular.R;

import java.util.ArrayList;

public class ShowPlaylist extends AppCompatActivity {

    private ListView lvShowPlaylist;
    private ArrayAdapter<String> arrayAdapter;
    private ArrayList<String> arrayList;

    public static int positionPlaylist;
    public static int positionSong;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_playlist);


        getWidget();
        init();
        click();



    }

    private void click() {
        lvShowPlaylist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (MusicActivity.mediaPlayer.isPlaying()){
                    MusicActivity.mediaPlayer.stop();
                    MusicActivity.mediaPlayer.release();
                }

                Intent intent=new Intent(ShowPlaylist.this,MusicActivity.class);
                positionSong=i;
                intent.putExtra("START_SONG_POSITION",positionSong);
                intent.putExtra("START_PLAYLIST_POSITION",positionPlaylist);
                startActivity(intent);
            }
        });
    }

    private void init() {
        Intent i=getIntent();
        positionPlaylist=i.getIntExtra("ShowPlaylist",-1);
        if (positionPlaylist!=-1){
            int size=PlaylistActivity.mListPlaylist.get(positionPlaylist).getPlaylistListSong().size();
            for(int j=0;j<size;j++){
                arrayList.add(PlaylistActivity.mListPlaylist.get(positionPlaylist).getPlaylistListSong().get(j).getmNameSong());
            }
            arrayAdapter.notifyDataSetChanged();
        }

    }

    private void getWidget() {

        lvShowPlaylist= (ListView) findViewById(R.id.lvShowPlaylist);
        arrayList=new ArrayList<>();
        arrayAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arrayList);

        lvShowPlaylist.setAdapter(arrayAdapter);
    }
}
