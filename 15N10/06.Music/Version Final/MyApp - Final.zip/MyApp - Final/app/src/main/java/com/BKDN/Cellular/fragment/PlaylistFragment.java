package com.BKDN.Cellular.fragment;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.BKDN.Cellular.PlaylistActivity;
import com.BKDN.Cellular.R;
import com.BKDN.Cellular.adapterRecycleView.PlaylistAdapterRecycleView;
import com.BKDN.Cellular.object.Playlist;

import java.util.ArrayList;

/**
 * Created by Administrator on 10/27/2017.
 */

public class PlaylistFragment extends Fragment {

    private RecyclerView recyclerView;

    private ArrayList<Playlist> arraylist;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.fragment_playlist, container, false);

        recyclerView= (RecyclerView) view.findViewById(R.id.recycleViewPlaylist);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this.getContext(),LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(linearLayoutManager);

        // lam duong bien
        DividerItemDecoration dividerItemDecoration=new DividerItemDecoration(this.getContext(),linearLayoutManager.getOrientation());
        recyclerView.addItemDecoration(dividerItemDecoration);


        arraylist=new ArrayList<>();

        arraylist.addAll(PlaylistActivity.mListPlaylist);

        PlaylistAdapterRecycleView playlistAdapterRecycle=new PlaylistAdapterRecycleView(PlaylistActivity.mListPlaylist,getContext());

        recyclerView.setAdapter(playlistAdapterRecycle);





        // Inflate the layout for this fragment
//        img =(ImageView) view.findViewById(R.id.img_logo);
//        img.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(getContext(), "da click", Toast.LENGTH_SHORT).show();
//            }
//        });
        return view;
    }
}
