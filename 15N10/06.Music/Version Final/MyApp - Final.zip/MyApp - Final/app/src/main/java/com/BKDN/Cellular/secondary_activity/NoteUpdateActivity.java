package com.BKDN.Cellular.secondary_activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.BKDN.Cellular.PlaylistActivity;
import com.BKDN.Cellular.R;

public class NoteUpdateActivity extends AppCompatActivity {

    private EditText edtNoteTitle;
    private EditText edtNoteDescribe;

    private Button btnUpdate;
    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_update);
        AnhXa();
        GetIntent();
        Click();
    }

    private void GetIntent() {
        Intent intent=getIntent();
        position=intent.getIntExtra("NOTE_POSITION",-1);
        if (position!=-1){
            String title=PlaylistActivity.mNoteList.get(position).getmNoteName();
            String detail=PlaylistActivity.mNoteList.get(position).getmDetail();
            edtNoteTitle.setText(title);
            edtNoteDescribe.setText(detail);

        }

    }

    private void AnhXa() {
        edtNoteTitle = (EditText) findViewById(R.id.edt_note_tittle);
        edtNoteDescribe = (EditText) findViewById(R.id.edt_note_describe);
        btnUpdate = (Button) findViewById(R.id.btnNoteUpdate);
    }

    private void Click() {
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtNoteTitle.getText().toString().isEmpty() || edtNoteDescribe.getText().toString().isEmpty()) {
                    Toast.makeText(NoteUpdateActivity.this, "Chưa nhập đủ rồi, liu liu !!!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(NoteUpdateActivity.this, "OK", Toast.LENGTH_SHORT).show();
                    Update();
                }
            }
        });
    }

    private void Update(){

        int id=PlaylistActivity.mNoteList.get(position).getmId();
        String name=edtNoteTitle.getText().toString();
        String detail=edtNoteDescribe.getText().toString();

        // myDatabase.QueryData("INSERT INTO Contact VALUES(null,'Xin chao','moi nguoi','hello','youtube','haha','android')");

        PlaylistActivity.myDatabase.QueryData("UPDATE Note SET Name='"+name+"' WHERE Id='"+id+"' ");
        PlaylistActivity.myDatabase.QueryData("UPDATE Note SET Detail='"+detail+"' WHERE Id='"+id+"' ");
        Intent intent=new Intent(NoteUpdateActivity.this,PlaylistActivity.class);
        startActivity(intent);
    }
}
