package com.BKDN.Cellular.secondary_activity;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;

import com.BKDN.Cellular.PlaylistActivity;
import com.BKDN.Cellular.R;

import java.util.Locale;

public class OpenActivity extends AppCompatActivity {

    String lang;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open);
        DialogLanguage();
    }

    private void DialogLanguage() {

        SharedPreferences sharePreferences = getPreferences(MODE_PRIVATE);
        boolean loadLanguage = sharePreferences.getBoolean("KEY_CHECK_LANGUAGE", true);
        final SharedPreferences.Editor editor=sharePreferences.edit();
        if (loadLanguage){
            editor.putBoolean("KEY_CHECK_LANGUAGE",false);
            Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.select_language);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

            ImageView imgVi= (ImageView) dialog.findViewById(R.id.imgVietnamese);
            ImageView imgEn= (ImageView) dialog.findViewById(R.id.imgEnglish);
            dialog.show();
            imgVi.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    lang="vi";
                    editor.putString("LANGUAGE",lang);
                    editor.commit();
                    SetLanguage(lang);
                    view.getContext().startActivity(new Intent(view.getContext(),PlaylistActivity.class));
                    finish();
                }
            });
            imgEn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    lang="en";
                    editor.putString("LANGUAGE",lang);
                    editor.commit();
                    SetLanguage(lang);
                    view.getContext().startActivity(new Intent(view.getContext(),PlaylistActivity.class));
                    finish();
                }
            });

        }
        else {
            String language=sharePreferences.getString("LANGUAGE","vi");
            SetLanguage(language);
            startActivity(new Intent(this,PlaylistActivity.class));
            finish();
        }



    }
    public void SetLanguage(String language){
        Locale myLocale = new Locale(language);
        Locale.setDefault(myLocale);
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale=myLocale;
        res.updateConfiguration(conf, dm);
    }
}
