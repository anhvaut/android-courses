package com.BKDN.Cellular.adapterRecycleView;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.BKDN.Cellular.PlaylistActivity;
import com.BKDN.Cellular.R;
import com.BKDN.Cellular.object.Song;
import com.BKDN.Cellular.secondary_activity.MusicActivity;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by Administrator on 10/27/2017.
 */

public class SongAdapterRecycleView extends RecyclerView.Adapter<SongAdapterRecycleView.Viewholder>{

    ArrayList<Song> songArraylist;
    Context context;

    public SongAdapterRecycleView(ArrayList<Song> songArraylist, Context context) {
        this.songArraylist = songArraylist;
        this.context = context;
    }

    @Override
    public Viewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(parent.getContext());
        View itemView=layoutInflater.inflate(R.layout.item_activity_list_song,parent,false);
        return new Viewholder(itemView);
    }

    @Override
    public void onBindViewHolder(Viewholder holder, int position) {
        holder.tvSongName.setText(songArraylist.get(position).getmNameSong().toString());
       // SimpleDateFormat dinhdanggio= new SimpleDateFormat("mm:ss");
       // String time=dinhdanggio.format()+"";
        holder.tvSongDuration.setText(songArraylist.get(position).getmTimeSong());
        holder.btnCount.setText(songArraylist.get(position).getCount()+"");

    }

    @Override
    public int getItemCount() {
        return songArraylist.size();
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        TextView tvSongName;
        TextView tvSongDuration;
        ImageView imgSongOption;
        Button btnCount;

        public Viewholder(final View itemView) {
            super(itemView);
            tvSongName= (TextView) itemView.findViewById(R.id.tv_song_name);
            tvSongDuration= (TextView) itemView.findViewById(R.id.tv_time_song);
            imgSongOption= (ImageView) itemView.findViewById(R.id.imgSongOption);
            btnCount= (Button) itemView.findViewById(R.id.btnSongCount);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {




                    if (MusicActivity.mediaPlayer.isPlaying()){
                        MusicActivity.mediaPlayer.stop();
                        MusicActivity.mediaPlayer.release();
                    }
                    int position=getAdapterPosition();
                    Intent intent = new Intent(itemView.getContext(), MusicActivity.class);
                    intent.putExtra("START_SONG_POSITION", position);
                    intent.putExtra("RECEIVE_INTENT_SONG",1122);
                   // intent.putExtra("SongList", (Serializable) mSongList);
                    itemView.getContext().startActivity(intent);
                }
            });

            imgSongOption.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Dialog dialog = new Dialog(view.getContext());
                    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                    dialog.setContentView(R.layout.custom_item_song);

                    TextView tvSetRingtone=dialog.findViewById(R.id.tvSetRingtone);
                    TextView tvDetail=dialog.findViewById(R.id.tvDetail);
                    String detail="*Name: "+PlaylistActivity.mSongList.get(getAdapterPosition()).getmNameSong()+
                            "\n*Duration: "+PlaylistActivity.mSongList.get(getAdapterPosition()).getmSongDuration()+
                            "\n*Path: "+ PlaylistActivity.mSongList.get(getAdapterPosition()).getmPathSong()+
                            "\n*Like: "+ PlaylistActivity.mSongList.get(getAdapterPosition()).getCount();
                    tvDetail.setText(detail);
                    tvSetRingtone.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Toast.makeText(view.getContext(), view.getResources().getString(R.string.txt_dat_lam_nhac_chuong) , Toast.LENGTH_SHORT).show();


                            /*
                            Uri newUri= Uri.parse(PlaylistActivity.mSongList.get(getAdapterPosition()).getmPathSong().toString());
                            try {
                                //RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_RINGTONE, newUri);
                                RingtoneManager.setActualDefaultRingtoneUri(view.getContext(), RingtoneManager.TYPE_RINGTONE, newUri);
                            }
                            catch (Throwable t) {
                            }*/

                            String b= Environment.getExternalStorageDirectory().getAbsolutePath();
                            String a=PlaylistActivity.mSongList.get(getAdapterPosition()).getmPathSong().toString();
                            File ring = new File(a);
                            Uri path = MediaStore.Audio.Media.getContentUriForPath(ring.getAbsolutePath());
                            RingtoneManager.setActualDefaultRingtoneUri(view.getContext(), RingtoneManager.TYPE_RINGTONE,path);

                          /*  String a=PlaylistActivity.mSongList.get(getAdapterPosition()).getmPathSong().toString();
                            //File ring = new File(a);
                            Uri path = MediaStore.Audio.Media.getContentUriForPath(a);
                            RingtoneManager.setActualDefaultRingtoneUri(view.getContext(), RingtoneManager.TYPE_RINGTONE,path);
*/

                        }
                    });

                    dialog.show();
                }
            });

            btnCount.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(view.getContext(), "Da tang", Toast.LENGTH_SHORT).show();
                    int count=songArraylist.get(getAdapterPosition()).getCount();
                    if (count<10) songArraylist.get(getAdapterPosition()).setCount(++count);
                    else {
                        count=0;
                        songArraylist.get(getAdapterPosition()).setCount(0);
                    }
                    btnCount.setText(count+"");
                    PlaylistActivity.myDatabase.QueryData("UPDATE Song SET Count='"+count+"' WHERE Id='"+songArraylist.get(getAdapterPosition()).getmSongId()+"'");

                }
            });

        }
    }
}



















