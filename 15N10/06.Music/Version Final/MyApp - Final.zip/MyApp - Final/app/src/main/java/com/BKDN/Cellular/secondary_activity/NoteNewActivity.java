package com.BKDN.Cellular.secondary_activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.BKDN.Cellular.PlaylistActivity;
import com.BKDN.Cellular.R;
import com.BKDN.Cellular.object.Note;

import java.text.SimpleDateFormat;
import java.util.Date;

public class NoteNewActivity extends AppCompatActivity {

    private EditText edtNoteTitle;
    private EditText edtNoteDescribe;

    private Button btnAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_new);
        AnhXa();
        Click();
    }

    private void AnhXa() {
        edtNoteTitle = (EditText) findViewById(R.id.edt_note_tittle);
        edtNoteDescribe = (EditText) findViewById(R.id.edt_note_describe);
        btnAdd = (Button) findViewById(R.id.btn_add_note);
    }

    private void Click() {
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtNoteTitle.getText().toString().isEmpty() || edtNoteDescribe.getText().toString().isEmpty()) {
                    Toast.makeText(NoteNewActivity.this, "Chưa nhập đủ rồi, liu liu !!!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(NoteNewActivity.this, "Đã thêm", Toast.LENGTH_SHORT).show();
                    add();
                }
            }
        });
    }

    private void add(){
        Note note=new Note();

        note.setmNoteName(edtNoteTitle.getText().toString());
        note.setmDetail(edtNoteDescribe.getText().toString());
        long day=System.currentTimeMillis();

        String date=new SimpleDateFormat("dd/MM/yyyy").format(new Date(day));
        note.setmNoteDate(date);

        String h=new SimpleDateFormat("hh:mm:ss").format(new Date(day));
        note.setmNoteTime(h);



        String name=edtNoteTitle.getText().toString();
        String detail=edtNoteDescribe.getText().toString();

        // myDatabase.QueryData("INSERT INTO Contact VALUES(null,'Xin chao','moi nguoi','hello','youtube','haha','android')");

        PlaylistActivity.myDatabase.QueryData("INSERT INTO Note VALUES(null,'"+name+"','"+detail+"','"+date+"','"+h+"')");
        Intent intent=new Intent(NoteNewActivity.this,PlaylistActivity.class);
        startActivity(intent);
    }
}
