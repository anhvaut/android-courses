package com.BKDN.Cellular.object;

import java.io.Serializable;

import ir.mirrajabi.searchdialog.core.Searchable;

/**
 * Created by Administrator on 9/9/2017.
 */

public class Song implements Serializable , Searchable {
    private long mId;// id bai hat
    private String mSongName;
    private String mSongDuration;
    private String mSongPath;

    private int mSongId;//id trong database

    private int count;

    public Song(String mSongName, String mSongDuration, String mSongPath, long mId, int mSongId) {
        this.mSongName = mSongName;
        this.mSongDuration = mSongDuration;
        this.mSongPath = mSongPath;
        this.mId = mId;
        this.mSongId = mSongId;
    }

    /// dang su dung
    public Song(int mSongId, String mSongName, String mSongDuration, String mSongPath, int count){
        this.mSongId=mSongId;
        this.mSongName=mSongName;
        this.mSongDuration=mSongDuration;
        this.mSongPath=mSongPath;
        this.count=count;
    }
    public Song(long mId, String mSongName, String mSongDuration, String mSongPath, int mSongId, int count) {
        this.mId = mId;
        this.mSongName = mSongName;
        this.mSongDuration = mSongDuration;
        this.mSongPath = mSongPath;
        this.mSongId = mSongId;
        this.count = count;
    }

    public Song(String mNameSong, String mTimeSong) {
        this.mSongName = mNameSong;
        this.mSongDuration = mTimeSong;
    }

    public Song(String mNameSong, String mTimeSong, String mPathSong) {
        this.mSongName = mNameSong;
        this.mSongDuration = mTimeSong;
        this.mSongPath = mPathSong;
    }
//          hhhhhhhhhhhhhhhh
    public Song(String mNameSong, String mTimeSong, String mPathSong, long mId) {
        this.mSongName = mNameSong;
        this.mSongDuration = mTimeSong;
        this.mSongPath = mPathSong;
        this.mId = mId;
    }
    public Song(String mNameSong, String mTimeSong, String mPathSong,  int count, long mId) {
        this.mSongName = mNameSong;
        this.mSongDuration = mTimeSong;
        this.mSongPath = mPathSong;
        this.mId = mId;
        this.count=count;
    }

    public String getmSongName() {
        return mSongName;
    }

    public void setmSongName(String mSongName) {
        this.mSongName = mSongName;
    }

    public String getmSongDuration() {
        return mSongDuration;
    }

    public void setmSongDuration(String mSongDuration) {
        this.mSongDuration = mSongDuration;
    }

    public String getmSongPath() {
        return mSongPath;
    }

    public void setmSongPath(String mSongPath) {
        this.mSongPath = mSongPath;
    }

    public int getmSongId() {
        return mSongId;
    }

    public void setmSongId(int mSongId) {
        this.mSongId = mSongId;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public long getmId() {
        return mId;
    }

    public void setmId(long mId) {
        this.mId = mId;
    }

    public String getmPathSong() {
        return mSongPath;
    }

    public void setmPathSong(String mPathSong) {
        this.mSongPath = mPathSong;
    }

    @Override
    public String toString() {
        return "Song{" +
                "mSongName='" + mSongName + '\'' +
                ", mSongDuration='" + mSongDuration + '\'' +
                ", mSongPath='" + mSongPath + '\'' +
                ", mId=" + mId +
                ", mSongId=" + mSongId +
                '}';
    }

    public String getmNameSong() {
        return mSongName;
    }

    public void setmNameSong(String mNameSong) {
        this.mSongName = mNameSong;
    }

    public String getmTimeSong() {
        return mSongDuration;
    }

    public void setmTimeSong(String mTimeSong) {
        this.mSongDuration = mTimeSong;
    }

    @Override
    public String getTitle() {
        return mSongName+"-"+mSongDuration;
    }
}
