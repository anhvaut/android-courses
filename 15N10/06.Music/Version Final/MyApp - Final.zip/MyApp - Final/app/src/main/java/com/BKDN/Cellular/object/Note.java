package com.BKDN.Cellular.object;

/**
 * Created by Administrator on 9/9/2017.
 */

public class Note {
    private int mId;
    private String mNoteName;
    private String mNoteDate;
    private String mNoteTime;
    private String mDetail;

    public Note() {
    }
    public Note(int mId, String mNoteName, String mNoteDate, String mNoteTime, String mDetail) {
        this.mId = mId;
        this.mNoteName = mNoteName;
        this.mNoteDate = mNoteDate;
        this.mNoteTime = mNoteTime;
        this.mDetail = mDetail;
    }

    public String getmDetail() {
        return mDetail;
    }

    public void setmDetail(String mDetail) {
        this.mDetail = mDetail;
    }

    public int getmId() {
        return mId;
    }

    public void setmId(int mId) {
        this.mId = mId;
    }

    public String getmNoteTime() {
        return mNoteTime;
    }

    public void setmNoteTime(String mNoteTime) {
        this.mNoteTime = mNoteTime;
    }

    @Override
    public String toString() {
        return "Note{" +
                "mNoteName='" + mNoteName + '\'' +
                ", mNoteDate='" + mNoteDate + '\'' +
                '}';
    }

    public String getmNoteName() {
        return mNoteName;
    }

    public void setmNoteName(String mNoteName) {
        this.mNoteName = mNoteName;
    }

    public String getmNoteDate() {
        return mNoteDate;
    }

    public void setmNoteDate(String mNoteDate) {
        this.mNoteDate = mNoteDate;
    }

}
