package com.santteam.apphenhosinhvien;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.santteam.apphenhosinhvien.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class ChatActivity extends AppCompatActivity {
    private Toolbar mToolbarChat;
    private ImageView mAdd,mSendChat;
    private EditText mNoiDungChat;
    private String mUserID,mNameUser;
    private TextView mUsername,mLastSeen;
    private CircleImageView mAnhDaiDien;
    private RecyclerView mMessagesList;

    private DatabaseReference mRootRef;
    private FirebaseAuth mAuth;
    private FirebaseUser mCurrentUser;
    private StorageReference mImageStorage;
    private DatabaseReference mFriendsDatabase;
    private DatabaseReference mCurrentStateChatsDatabase;

    private ArrayList<Messages> messagesList = new ArrayList<>();
    private MessagesAdapter mMessagesAdapter;

    private ProgressDialog mImageProgress;
    private LinearLayout mlnChucNang,mlnXacNhan;
    private Button mXacNhan,mTuChoi;


    private int GALLERY_PICK = 1;

    private int mCheck_BanBe = 0;
    private int mCheck_XacNhan = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        Intent intent = getIntent();
        if(intent != null){
            mUserID = intent.getStringExtra("ID");
        }
        addControls();
        addFirebase();
        if(mCurrentUser != null) {
            Toast.makeText(this, mCheck_BanBe + "", Toast.LENGTH_SHORT).show();
            setSupportActionBar(mToolbarChat);
            final ActionBar actionBar = getSupportActionBar();
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowCustomEnabled(true);

            LayoutInflater inflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            final View actionBarView = inflater.inflate(R.layout.chat_custom_bar, null);

            actionBar.setCustomView(actionBarView);

            //--------Custom action bar
            mUsername = (TextView) findViewById(R.id.tvUsername);
            mLastSeen = (TextView) findViewById(R.id.tvLastSeen);
            mAnhDaiDien = (CircleImageView) findViewById(R.id.imgAnhDaiDien);

            mMessagesAdapter = new MessagesAdapter(ChatActivity.this, messagesList);
            mMessagesList.setAdapter(mMessagesAdapter);

            loadMessage();

            mRootRef.child("users").child(mUserID).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    mNameUser = dataSnapshot.child("username").getValue().toString();
                    String linkImage = dataSnapshot.child("anhdaidien").getValue().toString();
                    String online = dataSnapshot.child("online").getValue().toString();
                    if (online.equals("true")) {
                        mLastSeen.setText("Online");
                    } else {
                        GetTimeAgo getTimeAgo = new GetTimeAgo();
                        long lastTime = Long.parseLong(online);
                        String lastSeenTime = (String) DateUtils.getRelativeDateTimeString(getApplicationContext(), lastTime, DateUtils.MINUTE_IN_MILLIS, DateUtils.WEEK_IN_MILLIS, DateUtils.FORMAT_NUMERIC_DATE);
                        mLastSeen.setText(lastSeenTime);
                    }

                    mUsername.setText(mNameUser);
                    Picasso.with(getBaseContext()).load(linkImage).placeholder(R.drawable.img_add_default).into(mAnhDaiDien);
                    //kiem tra xac nhan
                    mCurrentStateChatsDatabase.child(mCurrentUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            if (dataSnapshot.hasChild(mUserID)) {
                                String req_chat_type = dataSnapshot.child(mUserID).child("request_chat_type").getValue().toString();
                                if (req_chat_type.equals("received")) {
                                    Toast.makeText(ChatActivity.this, "chay ok" + req_chat_type, Toast.LENGTH_SHORT).show();
                                    //mlnChucNang.setVisibility(View.GONE);
                                    mlnXacNhan.setVisibility(View.VISIBLE);

                                }
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });

            mRootRef.child("chats").child(mCurrentUser.getUid())
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            if (!dataSnapshot.hasChild(mUserID)) {


                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }

                    });

            mSendChat.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    sendMessage();
                    mNoiDungChat.setText("");

                }
            });

            mImageStorage = FirebaseStorage.getInstance().getReference();
            mAdd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent galleryIntent = new Intent();
                    galleryIntent.setType("image/*");
                    galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(Intent.createChooser(galleryIntent, "SELECT IMAGE"), GALLERY_PICK);
                }
            });


            mTuChoi.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    mRootRef.child("chat_requests").child(mCurrentUser.getUid()).child(mUserID).removeValue();

                    mRootRef.child("message_requests").child(mCurrentUser.getUid()).child(mUserID).removeValue();

                }
            });

            mXacNhan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //chuyen chat_request sang chat
                    mRootRef.child("chats").child(mUserID).child(mCurrentUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            String lastmessage = dataSnapshot.child("lastmessage").getValue().toString();
                            long timestamp = Long.parseLong(dataSnapshot.child("timestamp").getValue().toString());

                            Map chatAddMap = new HashMap();
                            chatAddMap.put("seen", false);
                            chatAddMap.put("timestamp", timestamp);
                            chatAddMap.put("lastmessage", lastmessage.equals("") ? "Không có tin nhắn nào" : lastmessage);
                            Map chatUserMap = new HashMap();
                            chatUserMap.put("chats/" + mCurrentUser.getUid() + "/" + mUserID, chatAddMap);

                            mRootRef.updateChildren(chatUserMap, new DatabaseReference.CompletionListener() {
                                @Override
                                public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {

                                    if (databaseError != null) {
                                        Log.d("CHAT_LOG", databaseError.getMessage().toString());
                                    }

                                }
                            });

                            mRootRef.child("chat_requests").child(mCurrentUser.getUid()).child(mUserID).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    mRootRef.child("chat_requests").child(mUserID).child(mCurrentUser.getUid()).removeValue();
                                }
                            });

                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });


                    //chuyen chat request_message sang message
                    mRootRef.child("messages").child(mUserID).child(mCurrentUser.getUid()).addChildEventListener(new ChildEventListener() {

                        @Override
                        public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                            String push_id = dataSnapshot.getKey();
                            String from = dataSnapshot.child("from").getValue().toString();
                            String message = dataSnapshot.child("message").getValue().toString();
                            Long time = Long.parseLong(dataSnapshot.child("time").getValue().toString());
                            String type = dataSnapshot.child("type").getValue().toString();

                            String current_user_ref = "messages/" + mCurrentUser.getUid() + "/" + mUserID;

                            Map messageMap = new HashMap();
                            messageMap.put("message", message);
                            messageMap.put("seen", false);
                            messageMap.put("type", type);
                            messageMap.put("time", time);
                            messageMap.put("from", from);
                            updateChats(message);
                            Map messageUserMap = new HashMap();
                            messageUserMap.put(current_user_ref + "/" + push_id, messageMap);


                            mRootRef.updateChildren(messageUserMap, new DatabaseReference.CompletionListener() {
                                @Override
                                public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                                    if (databaseError != null) {
                                        Log.d("CHAT_LOG", databaseError.getMessage().toString());
                                    }
                                }
                            });

                            mRootRef.child("message_requests").child(mCurrentUser.getUid()).child(mUserID).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    mRootRef.child("message_requests").child(mUserID).child(mCurrentUser.getUid()).removeValue();
                                }
                            });

                        }

                        @Override
                        public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                        }

                        @Override
                        public void onChildRemoved(DataSnapshot dataSnapshot) {

                        }

                        @Override
                        public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                    mRootRef.child("current_state_chats").child(mCurrentUser.getUid()).child(mUserID).child("request_chat_type").setValue("ok").addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            mRootRef.child("current_state_chats").child(mUserID).child(mCurrentUser.getUid()).child("request_chat_type").setValue("ok").addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    mlnChucNang.setVisibility(View.VISIBLE);
                                    mlnXacNhan.setVisibility(View.GONE);
                                }
                            });
                        }
                    });


                }
            });
        }
    }

    private void addFirebase() {
        mRootRef = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();
        mCurrentUser = mAuth.getCurrentUser();
        mFriendsDatabase = FirebaseDatabase.getInstance().getReference().child("friends");
        mCurrentStateChatsDatabase = FirebaseDatabase.getInstance().getReference().child("current_state_chats");


    }

    private Boolean kiemTraBanBe() {
        mFriendsDatabase.child(mCurrentUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild(mUserID)){
                    mCheck_BanBe = 1;
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        if(mCheck_BanBe == 1) return true;
        return false;
    }
    private Boolean checkXacNhan() {
        if(mCurrentUser != null) {
            if(mCurrentStateChatsDatabase.child(mCurrentUser.getUid()).child(mUserID) != null) {
                mRootRef.child("current_state_chats").child(mCurrentUser.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.hasChild(mUserID)) {
                            String mCurrentState = dataSnapshot.child(mUserID).child("request_chat_type").getValue().toString();
                            if (mCurrentState.equals("ok")) {
                                Toast.makeText(ChatActivity.this, mCurrentState, Toast.LENGTH_SHORT).show();
                                mCheck_XacNhan = 1;
                            }
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
            if (mCheck_XacNhan == 1) return true;
            return false;
        }
        return false;
    }
    private void updateChats(String s) {
        if(kiemTraBanBe() || checkXacNhan()) {
            Map chatAddMap = new HashMap();
            chatAddMap.put("seen", false);
            chatAddMap.put("timestamp", ServerValue.TIMESTAMP);
            chatAddMap.put("lastmessage", s.equals("") ? "Không có tin nhắn nào" : s);
            Map chatUserMap = new HashMap();
            chatUserMap.put("chats/" + mCurrentUser.getUid() + "/" + mUserID, chatAddMap);
            chatUserMap.put("chats/" + "/" + mUserID + "/" + mCurrentUser.getUid(), chatAddMap);

            mRootRef.updateChildren(chatUserMap, new DatabaseReference.CompletionListener() {
                @Override
                public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {

                    if (databaseError != null) {
                        Log.d("CHAT_LOG", databaseError.getMessage().toString());
                    }

                }
            });
        }else{
            Map chatAddMap = new HashMap();
            chatAddMap.put("seen", false);
            chatAddMap.put("timestamp", ServerValue.TIMESTAMP);
            chatAddMap.put("lastmessage", s.equals("") ? "Không có tin nhắn nào" : s);
            Map chatUserMap = new HashMap();
            //chatUserMap.put("chat_requests/" + mCurrentUser.getUid() + "/" + mUserID, chatAddMap);
            chatUserMap.put("chat_requests/" + "/" + mUserID + "/" + mCurrentUser.getUid(), chatAddMap);

            chatUserMap.put("chats/" + mCurrentUser.getUid() + "/" + mUserID, chatAddMap);
            mRootRef.updateChildren(chatUserMap, new DatabaseReference.CompletionListener() {
                @Override
                public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {

                    if (databaseError != null) {
                        Log.d("CHAT_LOG", databaseError.getMessage().toString());
                    }

                }
            });
        }
    }



    private void loadMessage() {

        if(kiemTraBanBe() || checkXacNhan()) {

            mRootRef.child("messages").child(mCurrentUser.getUid()).child(mUserID).addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                    Toast.makeText(ChatActivity.this, "messages / Mi chạy ở đây à", Toast.LENGTH_SHORT).show();
                    Messages mess = dataSnapshot.getValue(Messages.class);
                    mess.setFrom(dataSnapshot.child("from").getValue().toString());
                    messagesList.add(mess);
                    mMessagesAdapter.notifyDataSetChanged();

                    mMessagesList.scrollToPosition(messagesList.size() - 1);
                }

                @Override
                public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                }

                @Override
                public void onChildRemoved(DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }else{
            Toast.makeText(ChatActivity.this, "request messages / Mi chạy ở đây à", Toast.LENGTH_SHORT).show();
            mRootRef.child("message_requests").child(mCurrentUser.getUid()).child(mUserID).addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                    Messages mess = dataSnapshot.getValue(Messages.class);
                    mess.setFrom(dataSnapshot.child("from").getValue().toString());
                    messagesList.add(mess);
                    mMessagesAdapter.notifyDataSetChanged();
                    mMessagesList.scrollToPosition(messagesList.size() - 1);
                }
                @Override
                public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                }
                @Override
                public void onChildRemoved(DataSnapshot dataSnapshot) {

                }
                @Override
                public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                }
                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }
    }


    private void sendMessage() {
        String message = mNoiDungChat.getText().toString().trim();
        if(!message.equals("")){
            if(kiemTraBanBe() || checkXacNhan()) {
                Toast.makeText(this, "message chat", Toast.LENGTH_SHORT).show();
                //dua tin nhan vao hop thu chat
                String current_user_ref = "messages/" + mCurrentUser.getUid() + "/" + mUserID;
                String chat_user_ref = "messages/" +  mUserID + "/" +mCurrentUser.getUid();

                DatabaseReference user_message_push = mRootRef.child("messages")
                        .child(mCurrentUser.getUid()).child(mUserID).push();

                String push_id = user_message_push.getKey();

                Map messageMap = new HashMap();
                messageMap.put("message", message);
                messageMap.put("seen", false);
                messageMap.put("type", "text");
                messageMap.put("time", ServerValue.TIMESTAMP);
                messageMap.put("from", mCurrentUser.getUid());
                updateChats(message);
                Map messageUserMap = new HashMap();
                messageUserMap.put(current_user_ref + "/" + push_id, messageMap);
                messageUserMap.put(chat_user_ref + "/" + push_id, messageMap);


                mRootRef.updateChildren(messageUserMap, new DatabaseReference.CompletionListener() {
                    @Override
                    public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                        if (databaseError != null) {
                            Log.d("CHAT_LOG", databaseError.getMessage().toString());
                        }
                    }
                });
            }else{
                Toast.makeText(this, "request message chat", Toast.LENGTH_SHORT).show();
                //dua tin nhan vao hop thu request chat
                String current_user_ref_req = "message_requests/" + mCurrentUser.getUid() + "/" + mUserID;
                String chat_user_ref_req = "message_requests/" +  mUserID + "/" +mCurrentUser.getUid();

                String current_user_ref = "messages/" + mCurrentUser.getUid() + "/" + mUserID;

                DatabaseReference user_message_request_push = mRootRef.child("message_requests")
                        .child(mCurrentUser.getUid()).child(mUserID).push();

                String push_id = user_message_request_push.getKey();

                Map messageMap = new HashMap();
                messageMap.put("message", message);
                messageMap.put("seen", false);
                messageMap.put("type", "text");
                messageMap.put("time", ServerValue.TIMESTAMP);
                messageMap.put("from", mCurrentUser.getUid());
                updateChats(message);
                Map messageUserMap = new HashMap();
                messageUserMap.put(current_user_ref_req + "/" + push_id, messageMap);
                messageUserMap.put(chat_user_ref_req + "/" + push_id, messageMap);

                messageUserMap.put(current_user_ref + "/" + push_id, messageMap);

                mRootRef.updateChildren(messageUserMap, new DatabaseReference.CompletionListener() {
                    @Override
                    public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                        if (databaseError != null) {
                            Log.d("CHAT_LOG", databaseError.getMessage().toString());
                        }
                    }
                });
                mCurrentStateChatsDatabase.child(mCurrentUser.getUid()).child(mUserID).child("request_chat_type")
                        .setValue("sent").addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        mCurrentStateChatsDatabase.child(mUserID).child(mCurrentUser.getUid()).child("request_chat_type")
                                .setValue("received");
                        }
                    });
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == GALLERY_PICK && resultCode == RESULT_OK && data != null){
            mImageProgress = new ProgressDialog(this);
            mImageProgress.setTitle("Sending Image");
            mImageProgress.setMessage("Chúng tôi đang gửi ảnh cho bạn. Vui lòng đợi trong giây lát");
            mImageProgress.setCanceledOnTouchOutside(false);
            mImageProgress.show();
            Uri imageUri = data.getData();
            if(mCurrentUser != null) {
                if (kiemTraBanBe() || checkXacNhan()) {

                    final String current_user_ref = "messages/" + mCurrentUser.getUid() + "/" + mUserID;
                    final String chat_user_ref = "messages/" + mUserID + "/" + mCurrentUser.getUid();

                    DatabaseReference user_message_push = mRootRef.child("messages")
                            .child(mCurrentUser.getUid()).child(mUserID).push();

                    final String push_id = user_message_push.getKey();

                    StorageReference filepath = mImageStorage.child("message_images").child(push_id + ".jpg");
                    filepath.putFile(imageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                            if (task.isSuccessful()) {

                                String download_uri = task.getResult().getDownloadUrl().toString();

                                Map messageMap = new HashMap();
                                messageMap.put("message", download_uri);
                                messageMap.put("seen", false);
                                messageMap.put("type", "image");
                                messageMap.put("time", ServerValue.TIMESTAMP);
                                messageMap.put("from", mCurrentUser.getUid());
                                updateChats(download_uri);
                                Map messageUserMap = new HashMap();
                                messageUserMap.put(current_user_ref + "/" + push_id, messageMap);
                                messageUserMap.put(chat_user_ref + "/" + push_id, messageMap);

                                mRootRef.updateChildren(messageUserMap, new DatabaseReference.CompletionListener() {
                                    @Override
                                    public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                                        if (databaseError != null) {
                                            Log.d("CHAT_LOG", databaseError.getMessage().toString());
                                        }
                                    }
                                });
                                mImageProgress.dismiss();

                            } else {
                                mImageProgress.hide();
                                Toast.makeText(ChatActivity.this, "Gửi ảnh không thành công", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                } else {
                    final String current_user_ref_req = "message_requests/" + mCurrentUser.getUid() + "/" + mUserID;
                    final String chat_user_ref_req = "message_requests/" + mUserID + "/" + mCurrentUser.getUid();
                    final String chat_user_ref = "messages/" + mCurrentUser.getUid() + "/" + mUserID;

                    DatabaseReference user_message_push = mRootRef.child("message_requests")
                            .child(mCurrentUser.getUid()).child(mUserID).push();

                    final String push_id = user_message_push.getKey();

                    StorageReference filepath = mImageStorage.child("message_images").child(push_id + ".jpg");
                    filepath.putFile(imageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                            if (task.isSuccessful()) {

                                String download_uri = task.getResult().getDownloadUrl().toString();

                                Map messageMap = new HashMap();
                                messageMap.put("message", download_uri);
                                messageMap.put("seen", false);
                                messageMap.put("type", "image");
                                messageMap.put("time", ServerValue.TIMESTAMP);
                                messageMap.put("from", mCurrentUser.getUid());
                                updateChats(download_uri);
                                Map messageUserMap = new HashMap();
                                messageUserMap.put(current_user_ref_req + "/" + push_id, messageMap);
                                messageUserMap.put(chat_user_ref_req + "/" + push_id, messageMap);
                                messageUserMap.put(chat_user_ref + "/" + push_id, messageMap);
                                mRootRef.updateChildren(messageUserMap, new DatabaseReference.CompletionListener() {
                                    @Override
                                    public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                                        if (databaseError != null) {
                                            Log.d("CHAT_LOG", databaseError.getMessage().toString());
                                        }
                                    }
                                });
                                mCurrentStateChatsDatabase.child(mCurrentUser.getUid()).child(mUserID).child("request_chat_type")
                                        .setValue("sent").addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        mCurrentStateChatsDatabase.child(mUserID).child(mCurrentUser.getUid()).child("request_chat_type")
                                                .setValue("received");
                                    }});
                                mImageProgress.dismiss();

                            } else {
                                mImageProgress.hide();
                                Toast.makeText(ChatActivity.this, "Gửi ảnh không thành công", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                }
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home){
            Intent listChatIntent = new Intent(ChatActivity.this,ListActivity.class);
            startActivity(listChatIntent);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void addControls() {

        mToolbarChat = findViewById(R.id.toolBarChat);
        mAdd = findViewById(R.id.imgAdd);
        mSendChat = findViewById(R.id.imgSend);
        mNoiDungChat = findViewById(R.id.edtNoiDung);
        mMessagesList = findViewById(R.id.rvListChatMessage);
        mlnChucNang = findViewById(R.id.lnChucNang);
        mlnXacNhan = findViewById(R.id.lnXacNhan);
        mXacNhan = findViewById(R.id.btnXacNhan);
        mTuChoi = findViewById(R.id.btnTuChoi);
        mMessagesList.setHasFixedSize(true);
        mMessagesList.setLayoutManager(new LinearLayoutManager(this));
    }

}
