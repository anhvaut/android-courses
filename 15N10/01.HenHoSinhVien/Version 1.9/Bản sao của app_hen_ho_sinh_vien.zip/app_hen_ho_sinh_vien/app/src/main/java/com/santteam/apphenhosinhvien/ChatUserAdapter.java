package com.santteam.apphenhosinhvien;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by nqait on 9/16/2017.
 */

public class ChatUserAdapter extends BaseAdapter{
    private Context context;
    private int layout;
    private List<ChatUser> chatUsers;


    public ChatUserAdapter(Context context, int layout, List<ChatUser> chatUsers) {
        this.context = context;
        this.layout = layout;
        this.chatUsers = chatUsers;
    }

    @Override
    public int getCount() {
        return chatUsers.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }
    public class ViewHolder{
        ImageView imgAnhDaiDien;
        TextView tvUsername,tvChat;
    }
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if(view == null) {
            //tạo context;
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = layoutInflater.inflate(layout,null);
            viewHolder = new ViewHolder();
            //Ánh xạ view
            viewHolder.imgAnhDaiDien = (ImageView)view.findViewById(R.id.imgAnhDaiDien);
            viewHolder.tvUsername = (TextView) view.findViewById(R.id.tvUsername);
            viewHolder.tvChat = (TextView) view.findViewById(R.id.tvChat);
            view.setTag(viewHolder);
        }
        else{
            viewHolder = (ViewHolder) view.getTag();
        }
        //Gán giá trị

        ChatUser chatUser = chatUsers.get(i);
        viewHolder.imgAnhDaiDien.setImageResource(chatUser.getAnhDaiDien());
        viewHolder.tvUsername.setText(chatUser.getUsername());
        viewHolder.tvChat.setText(chatUser.getChat());
        return view;
    }
}
