package com.santteam.apphenhosinhvien;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.santteam.apphenhosinhvien.model.KhachHang;
import com.santteam.apphenhosinhvien.model.SoThich;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;


public class TimKiemActivity extends AppCompatActivity {
    AutoCompleteTextView autoCompleteTimKiem;
    RecyclerView rvUser;
    ImageButton imgBtnBack, imgBtnSearch, imgBtnLoc;
    private String mTuKhoa, gioitinh = "";
    private DatabaseReference databaseReference;
    private FirebaseUser mCurrentUser;
    private ArrayList<KhachHang> danhSachTimKiems = new ArrayList<>();
    private ArrayList<KhachHang> khachHangs;
    private ArrayList<KhachHang> danhSachKhachHangs = new ArrayList<>();
    private ArrayList<String> soThichs = new ArrayList<>();
    private RecyclerAdapterKhachHang recyclerAdapterKhachHang;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tim_kiem);
        Intent intent = getIntent();
        if (intent != null) {
            soThichs = intent.getStringArrayListExtra("sothich");
            if (soThichs == null) {
                soThichs = new ArrayList<>();
            }
        }
        addControls();
        addFirebase();
        if (danhSachTimKiems.size() == 0) {
            recyclerAdapterKhachHang = new RecyclerAdapterKhachHang(khachHangs, TimKiemActivity.this);
            rvUser.setAdapter(recyclerAdapterKhachHang);
        }
        addEvents();
    }

    private void addFirebase() {
        databaseReference = FirebaseDatabase.getInstance().getReference().child("users");
        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        khachHangs = new ArrayList<>();

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                danhSachKhachHangs.clear();
                for(DataSnapshot dt : dataSnapshot.getChildren()){
                    danhSachKhachHangs.add(dt.getValue(KhachHang.class));
                }

                for(KhachHang kh : danhSachKhachHangs) {
                    if (kh.getID().equals(mCurrentUser.getUid().toString())) {
                        gioitinh = kh.getGioitinh().toString();
                        break;
                    }

                }

                for(KhachHang kh : danhSachKhachHangs) {

                    if (gioitinh.equals(kh.getGioitinh()) == false) {
                        if (soThichs.size() == 0) {
                            khachHangs.add(kh);
                        } else
                        {
                            int dem = 0;
                            for (String st : soThichs) {
                                if (kh.getSothich().contains(st)) {
                                    dem++;
                                }
                            }
                            if (dem > 0) {
                                khachHangs.add(kh);
                            }
                        }
                    }
                    long seed = System.nanoTime();
                    Collections.shuffle(khachHangs, new Random(seed));
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    private void addEvents() {
        imgBtnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mainIntent = new Intent(TimKiemActivity.this, MainActivity.class);
                startActivity(mainIntent);
                finish();
            }
        });
        imgBtnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                danhSachTimKiems.clear();
                mTuKhoa = autoCompleteTimKiem.getText().toString().trim();
                for (KhachHang kh : khachHangs) {
                    if (kh.getUsername().indexOf(mTuKhoa) == 0) {
                        danhSachTimKiems.add(kh);
                    }
                }
                recyclerAdapterKhachHang = new RecyclerAdapterKhachHang(danhSachTimKiems, TimKiemActivity.this);
                rvUser.setAdapter(recyclerAdapterKhachHang);
            }
        });

        imgBtnLoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(TimKiemActivity.this, LocActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void addControls() {
        imgBtnBack = (ImageButton) findViewById(R.id.imgBtnBack);
        imgBtnSearch = (ImageButton) findViewById(R.id.imgBtnSearch);
        imgBtnLoc = (ImageButton) findViewById(R.id.imgBtnLoc);
        rvUser = (RecyclerView) findViewById(R.id.rvUser);
        rvUser.setHasFixedSize(true);
        rvUser.setLayoutManager(new GridLayoutManager(this, 3));
        autoCompleteTimKiem = (AutoCompleteTextView) findViewById(R.id.autoCompleteTimKiem);
    }

    public void chuyenMH(String ID) {
        Intent trangCaNhanIntent = new Intent(TimKiemActivity.this, TrangCaNhanActivity.class);
        trangCaNhanIntent.putExtra("ID", ID);
        startActivity(trangCaNhanIntent);
        finish();
    }

}
