package com.santteam.apphenhosinhvien;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class DangNhapActivity extends AppCompatActivity {

    EditText edtMatKhau,edtTenDangNhap;
    TextView tvDangKy;
    Button btnDangNhap;
    private LoginButton btnlogin;
    private CallbackManager callbackManager;
    private FirebaseAuth mAuth ;
    private FirebaseAuth.AuthStateListener mAuthListener ;
    String TAG="";

    //Progress
    private ProgressDialog mLoginProgress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FacebookSdk.sdkInitialize(getApplicationContext());
        AppEventsLogger.activateApp(this);
        setContentView(R.layout.activity_dang_nhap);
        addControls();
        addEvens();
        loginface();
    }


    private void addEvens() {
        //----------Inten Sang Man Hinh Dang Ky---------
        tvDangKy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(DangNhapActivity.this,DangKyActivity.class);
                startActivity(intent);
            }
        });
        btnDangNhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CheckLogin.Instance().setCheck(2);
                String email = edtTenDangNhap.getText().toString();
                String password = edtMatKhau.getText().toString();
                if(edtTenDangNhap.length()==0 || edtMatKhau.length()==0)
                    Toast.makeText(DangNhapActivity.this,"Nhập Thiếu Kìa !!",Toast.LENGTH_SHORT).show();
                else{
                    mLoginProgress.setTitle("Đang đăng nhập");
                    mLoginProgress.setMessage("Chúng tôi đang kiểm tra thông tin của bạn");
                    mLoginProgress.setCanceledOnTouchOutside(false);
                    mLoginProgress.show();
                    login_user(email,password);
                }
            }
        });
    }

    private void login_user(String email, String password) {
        mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    mLoginProgress.dismiss();

                    Intent mainIntent = new Intent(DangNhapActivity.this,MainActivity.class);
                    mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(mainIntent);
                    finish();

                }else{
                    mLoginProgress.hide();
                    Toast.makeText(DangNhapActivity.this,"Đăng nhập không thành công. Vui lòng kiểm tra lại thông tin!",Toast.LENGTH_SHORT).show();

                }
            }
        });
    }

    private void addControls() {
        edtMatKhau= (EditText) findViewById(R.id.edtMatKhau);
        edtTenDangNhap= (EditText) findViewById(R.id.edtTenDangNhap);
        tvDangKy= (TextView) findViewById(R.id.tvDangKy);
        btnDangNhap= (Button) findViewById(R.id.btnDangNhap);
        mLoginProgress = new ProgressDialog(DangNhapActivity.this);

        Intent intent = getIntent();
        String email = intent.getStringExtra("Email");
        String matKhau = intent.getStringExtra("Mat Khau");
        if (email != null && matKhau != null){
            edtTenDangNhap.setText(email);
            edtMatKhau.setText(matKhau);
        }
    }
    private void loginface (){
        btnlogin = (LoginButton) findViewById(R.id.btnlogin);
        callbackManager=CallbackManager.Factory.create();
        btnlogin.setReadPermissions("email", "public_profile");
        btnlogin.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                Log.d(TAG, "facebook:onSuccess:" + loginResult);
                handleFacebookAccessToken(loginResult.getAccessToken());
            }

            @Override
            public void onCancel() {
                Log.d(TAG, "facebook:onCancel");
            }

            @Override
            public void onError(FacebookException error) {
                Log.d(TAG, "facebook:onError", error);
            }
        });
        mAuth= FirebaseAuth.getInstance();
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user= firebaseAuth.getCurrentUser();
                if (user!=null){

                    // Log.d(TAG, "onAuthStateChanged:signed_in"+user.getUid());
                }else {
                    Log.d(TAG,"onAuthStateChanged:signed_out");
                }
            }
        };

    }

    @Override
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }
    @Override
    protected void onStop() {
        super.onStop();
        if (mAuthListener!=null){
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

    private void  handleFacebookAccessToken(AccessToken accessToken){
        Log.d(TAG, "handleFacebookAccessToken:" + accessToken);
        AuthCredential authCredential = FacebookAuthProvider.getCredential(accessToken.getToken());
        mAuth.signInWithCredential(authCredential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                Log.d(TAG, "signInWithCredential:success"+ task.isSuccessful());
                if (!task.isSuccessful()){
                    Log.w(TAG, "signInWithCredential:failure", task.getException());
                }
                Toast.makeText(DangNhapActivity.this, "Đăng nhập thành công !.",
                        Toast.LENGTH_SHORT).show();
                Intent intent=new Intent( DangNhapActivity.this ,MainActivity.class);
                startActivity(intent);
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        callbackManager.onActivityResult(requestCode,resultCode,data);
    }



}

