package com.santteam.apphenhosinhvien;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import com.santteam.apphenhosinhvien.model.SoThich;

import java.util.ArrayList;

public class LocActivity extends AppCompatActivity {
    Toolbar toolbar;
    Button btnXoaLoc;
    CheckBox chkToanHoc,chkHoiHoa,chkAmNhac,chkVatLy,chkHoaHoc;
    ArrayList<String> soThichs = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loc);
        addControls();
        toolbar.setTitle("Lọc Tìm Kiếm");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        if(SoThich.Intance().getSoThichs().size() > 0)
        {
            chkToanHoc.setChecked(SoThich.Intance().getSoThichs().get(0));
            chkHoiHoa.setChecked(SoThich.Intance().getSoThichs().get(1));
            chkAmNhac.setChecked(SoThich.Intance().getSoThichs().get(2));
            chkVatLy.setChecked(SoThich.Intance().getSoThichs().get(3));
            chkHoaHoc.setChecked(SoThich.Intance().getSoThichs().get(4));
        }

        addEvents();
    }

    private void addEvents() {
        btnXoaLoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chkToanHoc.setChecked(false);
                chkAmNhac.setChecked(false);
                chkHoiHoa.setChecked(false);
                chkVatLy.setChecked(false);
                chkHoaHoc.setChecked(false);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == android.R.id.home){
            soThichs.clear();
            SoThich.Intance().getSoThichs().clear();
            if(chkToanHoc.isChecked() == true){
                soThichs.add(chkToanHoc.getText().toString());
            }
            else{
                soThichs.remove(chkToanHoc.getText().toString());
            }
            if(chkHoiHoa.isChecked() == true){
                soThichs.add(chkHoiHoa.getText().toString());
            }
            else{
                soThichs.remove(chkHoiHoa.getText().toString());
            }
            if(chkAmNhac.isChecked() == true){
                soThichs.add(chkAmNhac.getText().toString());
            }
            else{
                soThichs.remove(chkAmNhac.getText().toString());
            }
            if(chkVatLy.isChecked() == true){
                soThichs.add(chkVatLy.getText().toString());
            }
            else{
                soThichs.remove(chkVatLy.getText().toString());
            }
            if(chkHoaHoc.isChecked() == true){
                soThichs.add(chkHoaHoc.getText().toString());
            }
            else{
                soThichs.remove(chkHoaHoc.getText().toString());
            }
            SoThich.Intance().getSoThichs().add(chkToanHoc.isChecked());
            SoThich.Intance().getSoThichs().add(chkHoiHoa.isChecked());
            SoThich.Intance().getSoThichs().add(chkAmNhac.isChecked());
            SoThich.Intance().getSoThichs().add(chkVatLy.isChecked());
            SoThich.Intance().getSoThichs().add(chkHoaHoc.isChecked());
            Intent intent = new Intent(this,TimKiemActivity.class);
            intent.putExtra("sothich",soThichs);
            startActivity(intent);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void addControls() {
        toolbar = (Toolbar) findViewById(R.id.toolBar);
        btnXoaLoc = (Button) findViewById(R.id.btnXoaLoc);
        chkToanHoc = (CheckBox) findViewById(R.id.chkToanHoc);
        chkHoiHoa = (CheckBox) findViewById(R.id.chkHoiHoa);
        chkAmNhac = (CheckBox) findViewById(R.id.chkAmNhac);
        chkVatLy = (CheckBox) findViewById(R.id.chkVatLy);
        chkHoaHoc = (CheckBox) findViewById(R.id.chkHoaHoc);

    }
}
