package com.santteam.apphenhosinhvien;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.santteam.apphenhosinhvien.model.KhachHang;

public class MenuActivity extends AppCompatActivity {

    Button btnDangXuat,btnDoiMatKhau,btnThietLapCaNhan;
    private DatabaseReference mOnlineDatabase;
    private FirebaseUser mCurrentUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        addControls();
        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        mOnlineDatabase = FirebaseDatabase.getInstance().getReference().child("users").child(mCurrentUser.getUid());
        addEvens();

    }

    private void addEvens() {
        btnDoiMatKhau.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MenuActivity.this,DoiMatKhauActivity.class);
                startActivity(intent);
                finish();
            }
        });
        btnDangXuat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mOnlineDatabase != null) {
                    mOnlineDatabase.child("online").setValue(ServerValue.TIMESTAMP);
                    FirebaseAuth.getInstance().signOut();
                    Intent chaoIntent=new Intent(MenuActivity.this,DangNhapActivity.class);
                    startActivity(chaoIntent);
                }
            }
        });
        btnThietLapCaNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuActivity.this,ThietLapCaNhan.class);
                startActivity(intent);
            }
        });
    }

    private void addControls() {
        btnDangXuat= (Button) findViewById(R.id.btnDangXuat);
        btnDoiMatKhau= (Button) findViewById(R.id.btnDoiMatKhau);
        btnThietLapCaNhan= (Button) findViewById(R.id.btnThietLapCaNhan);

    }
}
