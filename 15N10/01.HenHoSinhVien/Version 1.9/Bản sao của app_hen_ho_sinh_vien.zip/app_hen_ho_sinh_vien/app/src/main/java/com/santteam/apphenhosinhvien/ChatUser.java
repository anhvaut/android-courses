package com.santteam.apphenhosinhvien;

/**
 * Created by nqait on 9/16/2017.
 */

public class ChatUser {
    private String username;
    private String chat;
    private int anhDaiDien;

    public ChatUser(String username, String chat, int anhDaiDien) {
        this.username = username;
        this.chat = chat;
        this.anhDaiDien = anhDaiDien;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getChat() {
        return chat;
    }

    public void setChat(String chat) {
        this.chat = chat;
    }

    public int getAnhDaiDien() {
        return anhDaiDien;
    }

    public void setAnhDaiDien(int anhDaiDien) {
        this.anhDaiDien = anhDaiDien;
    }
}
