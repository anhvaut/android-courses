package com.example.assassin.smartbook;

import java.io.Serializable;

/**
 * Created by Assassin on 11/7/2017.
 */

public class Book implements Serializable {
    private String title;
    private String author;
    private String imageCover;
    private String content;
    private String bookId;

    public Book(String title, String author, String imageCover, String content, String bookId) {
        this.title = title;
        this.author = author;
        this.imageCover = imageCover;
        this.content = content;
        this.bookId = bookId;
    }
    public Book() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getImageCover() {
        return imageCover;
    }

    public void setImageCover(String imageCover) {
        this.imageCover = imageCover;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }
}