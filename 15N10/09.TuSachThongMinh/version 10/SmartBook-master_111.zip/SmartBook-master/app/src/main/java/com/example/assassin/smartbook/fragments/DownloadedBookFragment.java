package com.example.assassin.smartbook.fragments;


import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.assassin.smartbook.Book;
import com.example.assassin.smartbook.R;
import com.example.assassin.smartbook.ReadDownloadedActivity;
import com.example.assassin.smartbook.adapters.BookAdapter;
import com.example.assassin.smartbook.datamanager.DataManager;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class DownloadedBookFragment extends Fragment {
    private RecyclerView recyclerView;
    private ArrayList<Book> arrayList;
    private BookAdapter bookAdapter;
    private Dialog dialog;
    DataManager databaseManager;

    public DownloadedBookFragment() {
        // Required empty public constructor
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments
        return inflater.inflate(R.layout.fragment_downloaded_book, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle("Sách đã tải về");
        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerViewDownloadedBook);

        //tuy chinh recycler view
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2, GridLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(gridLayoutManager);

        //doc du lieu tu sqlite truyen vao mang arrayList
        databaseManager = new DataManager(getContext());

        arrayList = new ArrayList<Book>();
        arrayList = databaseManager.getAllBook();
        //tao adapter
        bookAdapter = new BookAdapter(arrayList, getContext());
        recyclerView.hasFixedSize();
        recyclerView.setAdapter(bookAdapter);
        bookAdapter.setOnItemClickedListener(new BookAdapter.OnItemClickedListener() {
            @Override
            public void onItemClick(Book book) {
                //Toast.makeText(ReadOnlineActivity.this, "", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getContext(), ReadDownloadedActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("book", book);
                intent.putExtra("bundle", bundle);
                startActivity(intent);
            }
        });
    }
}


