package com.example.assassin.smartbook;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.assassin.smartbook.datamanager.DataManager;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class ReadOnlineActivity extends AppCompatActivity {

    private ImageView imageCover;
    private TextView tvTitle, tvAuthor, tvContent;
    private DatabaseReference mDatabase;
    private Dialog dialog;
    private Typeface font;
    private RadioButton rbTextSmall, rbTextLarge;
    private Switch swNightMode;
    private Book sampleBook;
    DataManager databaseManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_online);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mDatabase =  FirebaseDatabase.getInstance().getReference();
        databaseManager = new DataManager(this);
        font = Typeface.createFromAsset(getAssets(), "fonts/Lora-Regular.ttf");

        findView();
        tvContent.setTypeface(font);
        dialog = new Dialog(ReadOnlineActivity.this);
        dialog.setTitle("Đang tải..");
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.loading_dialog);
        dialog.show();

        Intent intent = getIntent();
        Book book = (Book)intent.getBundleExtra("bundle").getSerializable("book");

        Glide.with(getApplicationContext())
                .load(book.getImageCover())
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.imagenotfound)
                .into(imageCover);
        tvTitle.setText(book.getTitle());
        tvAuthor.setText(book.getAuthor());

        Query myQuery = mDatabase.child("book").child(book.getBookId());
        myQuery.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                sampleBook = dataSnapshot.getValue(Book.class);
                tvContent.setText(sampleBook.getContent());
                dialog.dismiss();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }
    public void findView(){
        imageCover = (ImageView)findViewById(R.id.imageCover);
        tvTitle = (TextView)findViewById(R.id.textViewTitle);
        tvAuthor = (TextView)findViewById(R.id.textViewAuthor);
        tvContent = (TextView)findViewById(R.id.textViewContent);
        rbTextSmall = (RadioButton)findViewById(R.id.rbTextSmall);
        rbTextLarge = (RadioButton)findViewById(R.id.rbTextLarge);
        swNightMode = (Switch)findViewById(R.id.swNightMode);
    }

    public void onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch(view.getId()) {
            case R.id.rbTextSmall:
                if (checked)
                    tvContent.setTextSize(20);
                break;
            case R.id.rbTextLarge:
                if (checked)
                    tvContent.setTextSize(22);
                break;
        }
    }
    public void onChangeNightMode(View view) {
        if(swNightMode.isChecked()){
            tvContent.setTextColor(Color.WHITE);
            tvContent.setBackgroundColor(Color.BLACK);
        } else {
            tvContent.setTextColor(Color.BLACK);
            tvContent.setBackgroundColor(Color.WHITE);
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_read_online,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id==R.id.download){
            databaseManager.addBook(sampleBook);
            Toast.makeText(this, "Đã tải xuống!", Toast.LENGTH_SHORT).show();
        }
        if(item.getItemId()==android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);
    }

}