package com.example.assassin.smartbook.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.assassin.smartbook.Book;
import com.example.assassin.smartbook.R;

import java.util.ArrayList;

/**
 * Created by Assassin on 11/7/2017.
 */

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.ViewHolder> {
    private ArrayList<Book> arrayList;
    private Context context;

    public BookAdapter(ArrayList<Book> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View itemView = layoutInflater.inflate(R.layout.recycler_view_item, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        Glide.with(context)
                .load(arrayList.get(position).getImageCover())
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.imagenotfound)
                .into(holder.imageCover);
        holder.textViewTitle.setText(arrayList.get(position).getTitle());
        holder.textViewAuthor.setText(arrayList.get(position).getAuthor());
        holder.item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onItemClickedListener != null) {
                    onItemClickedListener.onItemClick(arrayList.get(position));
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageCover;
        TextView textViewTitle, textViewAuthor;
        LinearLayout item;
        public ViewHolder(View itemView) {
            super(itemView);
            imageCover = (ImageView) itemView.findViewById(R.id.imageCover);
            textViewTitle = (TextView) itemView.findViewById(R.id.textViewTitle);
            textViewAuthor = (TextView) itemView.findViewById(R.id.textViewAuthor);
            item = (LinearLayout)itemView.findViewById(R.id.item);
        }
    }
    public interface OnItemClickedListener {
        void onItemClick(Book book);
    }

    private OnItemClickedListener onItemClickedListener;

    public void setOnItemClickedListener(OnItemClickedListener onItemClickedListener) {
        this.onItemClickedListener = onItemClickedListener;
    }
}