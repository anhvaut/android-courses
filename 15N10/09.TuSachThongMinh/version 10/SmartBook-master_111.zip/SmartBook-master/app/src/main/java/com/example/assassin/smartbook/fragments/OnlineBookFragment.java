package com.example.assassin.smartbook.fragments;


import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.assassin.smartbook.Book;
import com.example.assassin.smartbook.R;
import com.example.assassin.smartbook.ReadOnlineActivity;
import com.example.assassin.smartbook.adapters.BookAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class OnlineBookFragment extends Fragment {
    private RecyclerView recyclerView;
    private ArrayList<Book> arrayList;
    private BookAdapter bookAdapter;
    private Dialog dialog;
    private DatabaseReference mDatabase;
    private DatabaseReference bookCloudEndPoint;

    public OnlineBookFragment() {
        // Required empty public constructor
    }




    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //returning our layout file
        //change R.layout.yourlayoutfilename for each of your fragments
        return inflater.inflate(R.layout.fragment_online_book, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //you can set the title for your toolbar here for different fragments different titles
        getActivity().setTitle("Sách trực tuyến");
        recyclerView = (RecyclerView) view.findViewById(R.id.recyclerViewOnlineBook);


        mDatabase =  FirebaseDatabase.getInstance().getReference();
        bookCloudEndPoint = mDatabase.child("book");
        dialog = new Dialog(getContext());
        dialog.setTitle("Đang tải dữ liệu..");
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.loading_dialog);
        dialog.show();
        //addInitialDataToFirebase();

        //tuy chinh recycler view
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2, GridLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(gridLayoutManager);

        //doc du lieu tu firebase truyen vao mang arrayList
        arrayList = new ArrayList<Book>();
        Query myQuery = mDatabase.child("book");
        myQuery.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot: dataSnapshot.getChildren()) {
                    Book sampleBook = snapshot.getValue(Book.class);
                    arrayList.add(new Book(sampleBook.getTitle(),sampleBook.getAuthor(),sampleBook.getImageCover(), "",sampleBook.getBookId()));
                    bookAdapter.notifyDataSetChanged();

                }
                dialog.dismiss();


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
        //tao adapter
        bookAdapter = new BookAdapter(arrayList,getContext());
        recyclerView.hasFixedSize();
        recyclerView.setAdapter(bookAdapter);
        bookAdapter.setOnItemClickedListener(new BookAdapter.OnItemClickedListener() {
            @Override
            public void onItemClick(Book book) {
                //Toast.makeText(ReadOnlineActivity.this, "", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getContext(), ReadOnlineActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("book", book);
                intent.putExtra("bundle", bundle);
                startActivity(intent);
            }
        });
    }

    //write data firebase
    private void addInitialDataToFirebase() {
        Book sampleBook = new Book("Tuổi Trẻ Đáng Giá Bao Nhiêu","Rossie","https://girly.vn/wp-content/uploads/2017/08/tuoi-tre-dang-gia-bao-nhieu-cuon-sach-tuyet-voi-danh-cho-nguoi-tre.jpg","dsgd","");
        String key = bookCloudEndPoint.push().getKey();
        sampleBook.setBookId(key);
        bookCloudEndPoint.child(key).setValue(sampleBook);

    }
}