package com.example.assassin.smartbook.datamanager;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.assassin.smartbook.Book;

import java.util.ArrayList;

/**
 * Created by Assassin on 11/18/2017.
 */

public class DataManager extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "book";

    private static final String KEY_ID = "id";
    private static final String KEY_BOOKID = "bookId";
    private static final String KEY_TITLE = "title";
    private static final String KEY_AUTHOR = "author";
    private static final String KEY_IMAGECOVER = "imageCover";
    private static final String KEY_CONTENT = "content";


    public DataManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sql = String.format("CREATE TABLE %s(%s NUMBER PRIMARY KEY, %s TEXT, %s TEXT, %s TEXT,%s TEXT,%s TEXT)",
                TABLE_NAME, KEY_ID,KEY_BOOKID, KEY_TITLE, KEY_AUTHOR, KEY_IMAGECOVER, KEY_CONTENT);
        sqLiteDatabase.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void addBook(Book book){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(KEY_BOOKID, book.getBookId());
        contentValues.put(KEY_TITLE, book.getTitle());
        contentValues.put(KEY_AUTHOR, book.getAuthor());
        contentValues.put(KEY_IMAGECOVER, book.getImageCover());
        contentValues.put(KEY_CONTENT, book.getContent());

        db.insert(TABLE_NAME,null, contentValues);
        db.close();

    }

    public void deleteBook(Book book){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME,KEY_BOOKID+"=?",new String[]{String.valueOf(book.getBookId())} );
        db.close();
    }

    public ArrayList<Book> getAllBook(){
        ArrayList<Book> arrayList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT * FROM "+TABLE_NAME;
        Cursor cursor = db.rawQuery(sql,null);

        if(cursor.moveToFirst()){
            do {
                Book book = new Book();
                book.setBookId(cursor.getString(1));
                book.setTitle(cursor.getString(2));
                book.setAuthor(cursor.getString(3));
                book.setImageCover(cursor.getString(4));
                book.setContent(cursor.getString(5));
                arrayList.add(book);
            } while(cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return arrayList;
    }
}