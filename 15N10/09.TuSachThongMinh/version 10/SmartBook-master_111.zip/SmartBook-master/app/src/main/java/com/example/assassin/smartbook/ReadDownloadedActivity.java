package com.example.assassin.smartbook;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.assassin.smartbook.datamanager.DataManager;

public class ReadDownloadedActivity extends AppCompatActivity {

    private ImageView imageCover;
    private TextView tvTitle, tvAuthor, tvContent;
    private Typeface font;
    private RadioButton rbTextSmall, rbTextLarge;
    private Switch swNightMode;
    DataManager databaseManager;
    Book book;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_downloaded);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        font = Typeface.createFromAsset(getAssets(), "fonts/Lora-Regular.ttf");

        databaseManager = new DataManager(this);

        findView();
        tvContent.setTypeface(font);

        Intent intent = getIntent();
        book = (Book) intent.getBundleExtra("bundle").getSerializable("book");

        Glide.with(getApplicationContext())
                .load(book.getImageCover())
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.imagenotfound)
                .into(imageCover);
        tvTitle.setText(book.getTitle());
        tvAuthor.setText(book.getAuthor());
        tvContent.setText(book.getContent());


    }

    public void findView() {
        imageCover = (ImageView) findViewById(R.id.imageCover);
        tvTitle = (TextView) findViewById(R.id.textViewTitle);
        tvAuthor = (TextView) findViewById(R.id.textViewAuthor);
        tvContent = (TextView) findViewById(R.id.textViewContent);
        rbTextSmall = (RadioButton) findViewById(R.id.rbTextSmall);
        rbTextLarge = (RadioButton) findViewById(R.id.rbTextLarge);
        swNightMode = (Switch) findViewById(R.id.swNightMode);
    }

    public void onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.rbTextSmall:
                if (checked)
                    tvContent.setTextSize(20);
                break;
            case R.id.rbTextLarge:
                if (checked)
                    tvContent.setTextSize(22);
                break;
        }
    }

    public void onChangeNightMode(View view) {
        if (swNightMode.isChecked()) {
            tvContent.setTextColor(Color.WHITE);
            tvContent.setBackgroundColor(Color.BLACK);
        } else {
            tvContent.setTextColor(Color.BLACK);
            tvContent.setBackgroundColor(Color.WHITE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_read_downloaded, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.delete) {
            databaseManager.deleteBook(book);
            finish();
        }
        if (item.getItemId() == android.R.id.home)
            finish();
        return super.onOptionsItemSelected(item);
    }
}

